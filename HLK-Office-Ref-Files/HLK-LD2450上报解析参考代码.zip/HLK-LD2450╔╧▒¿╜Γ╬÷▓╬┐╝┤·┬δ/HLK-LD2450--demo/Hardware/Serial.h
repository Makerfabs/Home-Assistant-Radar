#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>

extern uint8_t Serial_TxPacket[];
extern uint8_t Serial_RxPacket[];
extern uint8_t pRxHead[];

void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);

void Serial_SendPacket(void);
uint8_t Serial_GetRxFlag(void);

// 2450雷达目标信息结构体
typedef struct HILINK
{
	int16_t m1_xCoordinate;		  // 目标1 x坐标
	int16_t m1_yCoordinate;		  // 目标1 y坐标
	int16_t m1_speed;			  // 目标1 速度
	int16_t m1_DistanceResolution; // 目标1距离分辨率
	double m1_distance;	//	目标1的距离
	double m1_angle_deg; 		//目标1的角度
	
	int16_t m2_xCoordinate;		  // 目标1 x坐标
	int16_t m2_yCoordinate;		  // 目标1 y坐标
	int16_t m2_speed;			  // 目标1 速度
	int16_t m2_DistanceResolution; // 目标1距离分辨率
	double m2_distance;	//	目标1的距离
	double m2_angle_deg; 		//目标1的角度
	
	int16_t m3_xCoordinate;		  // 目标1 x坐标
	int16_t m3_yCoordinate;		  // 目标1 y坐标
	int16_t m3_speed;			  // 目标1 速度
	int16_t m3_DistanceResolution; // 目标1距离分辨率
	double m3_distance;	//	目标1的距离
	double m3_angle_deg; 		//目标1的角度

} HILINK;

// 定义测试用的全局变量
extern HILINK HiLink_2450;



#endif
