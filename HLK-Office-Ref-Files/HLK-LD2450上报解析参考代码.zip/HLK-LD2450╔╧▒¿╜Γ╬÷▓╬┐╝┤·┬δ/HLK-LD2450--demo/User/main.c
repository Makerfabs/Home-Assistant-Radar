#include "stm32f10x.h" // Device header
#include "Serial.h"
#include <math.h>
#define M_PI 3.14159265358979323846

int main(void)
{
	Serial_Init();

	while (1)
	{

		if (Serial_GetRxFlag() == 1)
		{

			// 目标一
			if ((Serial_RxPacket[6] == 0x00 && Serial_RxPacket[7] == 0x00) != 1)
			{
				// 计算距离
				double distance = sqrt(HiLink_2450.m1_xCoordinate * HiLink_2450.m1_xCoordinate + HiLink_2450.m1_yCoordinate * HiLink_2450.m1_yCoordinate);
				HiLink_2450.m1_distance = distance;

				// 计算角度（弧度）
				double angle_rad = atan2(HiLink_2450.m1_xCoordinate, HiLink_2450.m1_yCoordinate);

				// 将角度转换为度数
				double angle_deg = -angle_rad * (180.0 / M_PI);

				HiLink_2450.m1_angle_deg = angle_deg;

				printf("x1:%d \n y1:%d \n speed1:%d \n DistanceResolution1:%d\n Distance1: %.2f\n Angle (degrees)1: %.2f\n",
					   HiLink_2450.m1_xCoordinate,
					   HiLink_2450.m1_yCoordinate,
					   HiLink_2450.m1_speed,
					   HiLink_2450.m1_DistanceResolution,
					   HiLink_2450.m1_distance,
					   HiLink_2450.m1_angle_deg);
			}

			
			
			// 目标二
			if ((Serial_RxPacket[14] == 0x00 && Serial_RxPacket[15] == 0x00) != 1)
			{
				// 计算距离
				double distance2 = sqrt(HiLink_2450.m2_xCoordinate * HiLink_2450.m2_xCoordinate + HiLink_2450.m2_yCoordinate * HiLink_2450.m2_yCoordinate);
				HiLink_2450.m2_distance = distance2;

				// 计算角度（弧度）
				double angle_rad2 = atan2(HiLink_2450.m2_xCoordinate, HiLink_2450.m2_yCoordinate);

				// 将角度转换为度数
				double angle_deg2 = -angle_rad2 * (180.0 / M_PI);

				HiLink_2450.m2_angle_deg = angle_deg2;
				printf("x2:%d \n y2:%d \n speed2:%d \n DistanceResolution2:%d\n Distance2: %.2f\n Angle (degrees)2: %.2f\n",
					   HiLink_2450.m2_xCoordinate,
					   HiLink_2450.m2_yCoordinate,
					   HiLink_2450.m2_speed,
					   HiLink_2450.m2_DistanceResolution,
					   HiLink_2450.m2_distance,
					   HiLink_2450.m2_angle_deg);
			}

			// 目标三
			if ((Serial_RxPacket[22] == 0x00 && Serial_RxPacket[23] == 0x00) != 1)
			{
				// 计算距离
				double distance3 = sqrt(HiLink_2450.m3_xCoordinate * HiLink_2450.m3_xCoordinate + HiLink_2450.m3_yCoordinate * HiLink_2450.m3_yCoordinate);
				HiLink_2450.m3_distance = distance3;

				// 计算角度（弧度）
				double angle_rad3 = atan2(HiLink_2450.m3_xCoordinate, HiLink_2450.m3_yCoordinate);

				// 将角度转换为度数
				double angle_deg3 = -angle_rad3 * (180.0 / M_PI);

				HiLink_2450.m3_angle_deg = angle_deg3;
				printf("x3:%d \n y3:%d \n speed3:%d \n DistanceResolution3:%d\n Distance3: %.2f\n Angle (degrees)3: %.2f\n",
					   HiLink_2450.m3_xCoordinate,
					   HiLink_2450.m3_yCoordinate,
					   HiLink_2450.m3_speed,
					   HiLink_2450.m3_DistanceResolution,
					   HiLink_2450.m3_distance,
					   HiLink_2450.m3_angle_deg);
			}
		}
	}
}
