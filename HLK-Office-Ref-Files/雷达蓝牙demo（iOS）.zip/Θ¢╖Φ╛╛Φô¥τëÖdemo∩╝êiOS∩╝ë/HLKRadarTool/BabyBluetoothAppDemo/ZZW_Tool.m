//
//  ZZW_Tool.m
//  SmartPhotoFrame
//
//  Created by mqw on 2021/9/14.
//

#import "ZZW_Tool.h"
#import <SystemConfiguration/CaptiveNetwork.h>

@implementation ZZW_Tool


+ (CGFloat)getStringHeightWithText:(NSString *)text font:(UIFont *)font viewWidth:(CGFloat)width {
    // 设置文字属性 要和label的一致
    NSDictionary *attrs = @{NSFontAttributeName :font};
    CGSize maxSize = CGSizeMake(width, MAXFLOAT);
    
    NSStringDrawingOptions options = NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    
    // 计算文字占据的宽高
    CGSize size = [text boundingRectWithSize:maxSize options:options attributes:attrs context:nil].size;
    
    // 当你是把获得的高度来布局控件的View的高度的时候.size转化为ceilf(size.height)。
    return  ceilf(size.height);
}


+ (CGFloat)getStringWidthWithText:(NSString *)text font:(UIFont *)font viewHeight:(CGFloat)height {
    // 设置文字属性 要和label的一致
    NSDictionary *attrs = @{NSFontAttributeName :font};
    CGSize maxSize = CGSizeMake(MAXFLOAT, height);
    
    NSStringDrawingOptions options = NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    
    // 计算文字占据的宽高
    CGSize size = [text boundingRectWithSize:maxSize options:options attributes:attrs context:nil].size;
    
    // 当你是把获得的高度来布局控件的View的高度的时候.size转化为ceilf(size.height)。
    return  ceilf(size.width);
}

+ (NSString *)ZZW_weekdaySortWithDayArray:(NSArray *)array {

    NSArray *titleArr = @[@"Mon",@"Tue",@"Wed",@"Thu",@"Fri",@"Sat",@"Sun"];

    NSArray *wholeArr = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7"];

    NSString *wholeStr = [wholeArr componentsJoinedByString:@""];

    NSArray *unSeleccArr = [wholeArr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"NOT (SELF in %@)", array]];

    NSString *unSelectStr = [unSeleccArr componentsJoinedByString:@""];

    NSArray *sortArr = [wholeStr componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:unSelectStr]];

    NSMutableArray *array1 = [NSMutableArray arrayWithArray:sortArr];

    [array1 removeObject:@""];

    NSMutableArray *goalArr;

    for (NSString *subStr in array1) {

        NSString *str1;

        if (subStr.length > 1) {
            str1 = [self reGetArrayWithString:subStr];
        } else {
            str1 = NSLocalizedString(titleArr[[subStr integerValue]-1], @"周一...周日");
        }

        if (!goalArr) {
            goalArr = [NSMutableArray array];
        }

        [goalArr addObject:str1];

    }

    NSString *finalStr = [goalArr componentsJoinedByString:@" "];

    return finalStr;

}

//array表示输入的选定的日期

+ (NSString *)reGetArrayWithString:(NSString *)string {

    NSArray *titleArr = @[@"Mon",@"Tue",@"Wed",@"Thu",@"Fri",@"Sat",@"Sun"];

    NSString *topStr = [string substringToIndex:1];

    NSString *bottomStr = [string substringFromIndex:string.length-1];

    NSString *goalStr;

    if (string.length >= 3) {
        goalStr = [NSString stringWithFormat:@"%@%@%@",NSLocalizedString(titleArr[[topStr integerValue]-1], @"周一...周日"), NSLocalizedString(@"zhi", @"至"), NSLocalizedString(titleArr[[bottomStr integerValue]-1], @"周一...周日")];

    } else {
        goalStr = [NSString stringWithFormat:@"%@ %@",NSLocalizedString(titleArr[[topStr integerValue]-1], @"周一...周日"),NSLocalizedString(titleArr[[bottomStr integerValue]-1], @"周一...周日")];

    }

    return goalStr;

}


+ (BOOL)isEmptyString:(NSString *)string {

if (!string) {//等价于if(string == ni||string == NULL)
    return YES;
}
if ([string isKindOfClass:[NSNull class]]) {//后台的数据可能是NSNull
    return YES;
}

if (!string.length) {//字符串长度

   return YES;
}

    NSCharacterSet *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];

    NSString *trimmedString = [string stringByTrimmingCharactersInSet:set];
    if (!trimmedString.length) {
        return YES;
        
    }
    return NO;

}


+ (NSString *)timeStamp:(NSString *)data
{
    //时间戳
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"]; // ----------设置你想要的格式,hh与HH的区别:分别表示12小时制,24小时制
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    [formatter setTimeZone:timeZone];
    // 时间戳转时间的方法
    NSString *str = [NSString stringWithFormat:@"%d",[data intValue]*1000];
    NSTimeInterval time=[str doubleValue];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:time];
    //NSLog(@"1383523892  = %@",confromTimesp);
    NSString *confromTimespStr = [formatter stringFromDate:confromTimesp];
    //NSLog(@"confromTimespStr =  %@",confromTimespStr);
    return confromTimespStr;
}

+(NSString*)timeWithYearMonthDayCountDown:(double)timestamp{// 时间戳转日期
    // 传入的时间戳timeStr如果是精确到毫秒的记得要/1000
    NSTimeInterval timeInterval=timestamp/1000;
    NSDate*detailDate=[NSDate dateWithTimeIntervalSince1970:timeInterval];
    NSDateFormatter*dateFormatter=[[NSDateFormatter alloc]init];
    // 实例化一个NSDateFormatter对象，设定时间格式，这里可以设置成自己需要的格式
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSString*dateStr=[dateFormatter stringFromDate:detailDate];
    return dateStr;
}

+ (NSString *)getTime {
    NSDate *timeDate = [NSDate date];
     NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
     [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
     NSString *locationString = [dateFormatter stringFromDate:timeDate];
    return [locationString substringWithRange:NSMakeRange(11, locationString.length-11)];
}

+ (NSString*)getPreferredLanguage
{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];

    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];

    NSString * preferredLang = [allLanguages objectAtIndex:0];

    NSLog(@"当前语言:%@", preferredLang);

    return preferredLang;

}

@end
