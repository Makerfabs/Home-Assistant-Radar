//
//  HexadecimalConversionTool.h
//  roller
//
//  Created by goblin on 2021/5/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 进制转换
@interface HexadecimalConversionTool : NSObject

/// 字符串转16进制data
+ (NSData *)dataWithHexString:(NSString *)hexString;

/// 16进制data转16进制字符数组
+ (NSArray *)dataToHexStringArray:(NSData *)data;
/// 16进制data转16进制字符串
+ (NSString *)dataToHexString:(NSData *)data;

/// 二进制转十进制
+ (NSString *)convertDecimalSystemFromBinarySystem:(NSString *)binary;
/// 10进制转16进制
+ (NSString *)ToHex:(NSString *)string;

/// 16进制转2进制
+ (NSString *)hexadecimalToBinary:(NSString *)string;
/// 16进制转2进制数组
+ (NSArray *)hexadecimalToBinaryArray:(NSString *)string;

/// 存储数据
+ (void)saveDataByKeyNSUserDefaults:(NSString *)strKey andValue:(NSString *)strValue;
/// 读取数据
+ (NSString *)readDataByKeyNSUserDefaults:(NSString *)strKey;


/// 二进制字符串转十进制字符串
/// @param binaryString <#binaryString description#>
+ (NSString *)binaryStringToString:(NSString *)binaryString;

@end

NS_ASSUME_NONNULL_END
