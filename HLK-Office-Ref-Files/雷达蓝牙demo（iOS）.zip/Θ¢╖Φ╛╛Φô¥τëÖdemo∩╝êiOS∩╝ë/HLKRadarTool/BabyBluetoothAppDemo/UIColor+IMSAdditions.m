//
//  UIColor+IMSAdditions.m
//  IMSCategory
//
//  Created by 冯君骅 on 2018/4/14.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIColor+IMSAdditions.h"

static NSMutableDictionary *cache;

static NSString* const kSystemMaticKey = @"SystemMatic";
static NSString* const kNegativeKey = @"Negative";
static NSString* const kTitleKey = @"Title";
static NSString* const kAccessaryKey = @"Accessary";
static NSString* const kAccessorialKey = @"Accessorial";
static NSString* const kMarginalKey = @"Marginal";
static NSString* const kBackgroundKey = @"Background";
static NSString* const kFillKey = @"Fill";

static NSUInteger const kSystemMaticColor = 0x00C989;
static NSUInteger const kNegativeColor = 0xFF352F;
static NSUInteger const kTitleColor = 0x333333;
static NSUInteger const kAccessaryColor = 0x999999;
static NSUInteger const kAccessorialColor = 0xAFB8BD;
static NSUInteger const kMarginalColor = 0xEDEDED;
static NSUInteger const kBackgroundColor = 0xF6F6F6;
static NSUInteger const kFillColor = 0xFFFFFF;

@implementation UIColor (IMSAdditions)

#pragma mark - LifeCircle

+ (void)load {
	[self configDefaultColorsWithPlist:@{kSystemMaticKey:@(kSystemMaticColor),
									   kNegativeKey:@(kNegativeColor),
									   kTitleKey:@(kTitleColor),
									   kAccessaryKey:@(kAccessaryColor),
									   kAccessorialKey:@(kAccessorialColor),
									   kMarginalKey:@(kMarginalColor),
									   kBackgroundKey:@(kBackgroundColor),
									   kFillKey:@(kFillColor)
									}];
}

#pragma mark - InitMethod
+ (UIColor *)ims_colorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue {
	return [UIColor ims_colorWithRed:red green:green blue:blue alpha:1.0f];
}
+ (UIColor *)ims_colorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue alpha:(CGFloat)alpha {
	return [UIColor colorWithRed:((red) / 255.0) green:((green) / 255.0) blue:((blue) / 255.0) alpha:(alpha)];
}

+ (UIColor *)ims_colorWithHexRGB:(NSUInteger)hexRGB {
	
	return [UIColor ims_colorWithHexRGB:hexRGB alpha:1.0f];
}
+ (UIColor *)ims_colorWithHexRGB:(NSUInteger)hexRGB alpha:(CGFloat)alpha {
	return [UIColor ims_colorWithRed:((float)((hexRGB & 0xFF0000) >> 16)) green:((float)((hexRGB & 0xFF00) >> 8)) blue:((float)(hexRGB & 0xFF)) alpha:alpha];
}

#pragma mark - CacheColor
+ (UIColor *)ims_systemMaticColor {
	return [self ims_colorWithCacheKey:kSystemMaticKey];
}
+ (UIColor *)ims_negativeColor {
	return [self ims_colorWithCacheKey:kNegativeKey];
}
+ (UIColor *)ims_titleColor {
	return [self ims_colorWithCacheKey:kTitleKey];
}
+ (UIColor *)ims_accessaryColor {
	return [self ims_colorWithCacheKey:kAccessaryKey];
}
+ (UIColor *)ims_accessorialColor {
	return [self ims_colorWithCacheKey:kAccessorialKey];
}
+ (UIColor *)ims_marginalColor {
	return [self ims_colorWithCacheKey:kMarginalKey];
}
+ (UIColor *)ims_backgroundColor {
	return [self ims_colorWithCacheKey:kBackgroundKey];
}
+ (UIColor *)ims_fillColor {
	return [self ims_colorWithCacheKey:kFillKey];
}

+ (UIColor *)ims_colorWithCacheKey:(NSString *)key {
	NSNumber *number = [cache valueForKey:key];
	if (number == nil || ![number isKindOfClass:[NSNumber class]]) {
		return nil;
	}
	NSUInteger value = [number unsignedIntegerValue];
	if (isnan(value) || isinf(value)) {
		return nil;
	}
	
	return [UIColor ims_colorWithHexRGB:value];
}

+ (void)configDefaultColorsWithPlist:(NSDictionary *)plist {
	static NSArray *keys = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		cache = [[NSMutableDictionary alloc] initWithCapacity:8];
		keys = @[kSystemMaticKey,kNegativeKey,kTitleKey,
				 kAccessaryKey,kAccessorialKey,kMarginalKey,
				 kBackgroundKey,kFillKey];
	});
	if (plist != nil) {
		[cache removeAllObjects];
		[plist enumerateKeysAndObjectsUsingBlock:^(NSString *colorName, NSNumber  *colorValue, BOOL * _Nonnull stop) {
			[keys enumerateObjectsUsingBlock:^(id  _Nonnull key, NSUInteger idx, BOOL * _Nonnull stop) {
				if ([colorName isEqualToString:key]) {
					[cache setValue:colorValue forKey:key];
				}
			}];
		}];
	}
}
@end
