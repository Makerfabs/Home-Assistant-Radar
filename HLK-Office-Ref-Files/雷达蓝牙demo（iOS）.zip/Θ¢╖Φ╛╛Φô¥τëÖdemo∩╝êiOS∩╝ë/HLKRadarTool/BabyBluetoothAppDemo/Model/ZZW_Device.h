//
//  ZZW_Device.h
//  HLKRadarTool
//
//  Created by 佐文周 on 2022/9/20.
//  Copyright © 2022 刘彦玮. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//判断固件版本，显示不同功能
typedef enum : int {
    /** 没有自定义广播包，旧固件 */
    No_Receive_Old = 1,
    /** 有自定义广播包，有版本号，没有密码校验，没有OTA，有分辨率 */
    Haved_Ver_No_CheckPwd_No_Upgrade_Haved_SPI = 2,
    /** 有自定义广播包，有版本号，有密码校验，有OTA，有分辨率 */
    Haved_Ver_Haved_CheckPwd_Haved_Upgrade_Haved_SPI = 3,
} DeviceType;

@interface ZZW_Device : NSObject

@property (nonatomic, strong) NSString *name;/**< 设备名称 */
@property (nonatomic, strong) NSString *keyName;/**< 设备广播名称  用于存储设备备注名 */
@property (nonatomic, strong) CBPeripheral *bleDevice;/**< 蓝牙对象 */
@property (nonatomic, strong) NSDictionary *bleDic;/**< 蓝牙广播字典 */
@property (nonatomic, strong) NSString *currentVersion;/**< 当前设备版本 */
@property (nonatomic, strong) NSString *macAddress;/**< 设备ID */
@property (nonatomic, strong) NSString *password;/**< 控制密码 */
@property (nonatomic, assign) DeviceType deviceType;/**< 设备类型 */
@property (nonatomic, assign) BOOL otaStatus;/**< OTA状态 YES==OTA中 */
@property (nonatomic, strong) NSString *serverVersion;/**< 服务器上版本 */
@property (nonatomic, assign) NSInteger fileSize;/**< 文件大小 */
@property (nonatomic, strong) NSNumber *RSSI;

@property (nonatomic, assign) BOOL selected;/** 是否选中（分享功能） */

@end

NS_ASSUME_NONNULL_END
