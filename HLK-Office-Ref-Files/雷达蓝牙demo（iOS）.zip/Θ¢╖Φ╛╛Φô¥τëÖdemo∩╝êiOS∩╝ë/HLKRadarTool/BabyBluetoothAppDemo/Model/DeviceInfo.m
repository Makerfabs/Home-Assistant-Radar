//
//  DeviceInfo.m
//  Qkeeper
//
//  Created by mqw on 15/11/9.
//  Copyright © 2015年 mqw. All rights reserved.
//

#import "DeviceInfo.h"
#import <CommonCrypto/CommonDigest.h>

#include "iconv.h"


@implementation DeviceInfo

- (id)init {
    self = [super init];
    if (self) {
        _recvLocalCommandStrDic  = [[NSMutableDictionary alloc]initWithCapacity:0];
    }
    return self;
}


+ (instancetype)sharedClient {
    static DeviceInfo *helper = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        helper = [[self alloc] init];
    });
    return helper;
}







- (unsigned char)getCheckCode:(unsigned char*)buffer withLen:(NSInteger)len {
    unsigned char res = 0;
    for (NSInteger i = 0; i < len; i++) {
        res += buffer[i];
    }
    res+=1;
    return res;
}
+(NSString *)getBinaryByhex:(NSString *)hex
{
    NSMutableDictionary  *hexDic = [[NSMutableDictionary alloc] init];
    hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    [hexDic setObject:@"0000" forKey:@"0"];
    [hexDic setObject:@"0001" forKey:@"1"];
    [hexDic setObject:@"0010" forKey:@"2"];
    [hexDic setObject:@"0011" forKey:@"3"];
    [hexDic setObject:@"0100" forKey:@"4"];
    [hexDic setObject:@"0101" forKey:@"5"];
    [hexDic setObject:@"0110" forKey:@"6"];
    [hexDic setObject:@"0111" forKey:@"7"];
    [hexDic setObject:@"1000" forKey:@"8"];
    [hexDic setObject:@"1001" forKey:@"9"];
    [hexDic setObject:@"1010" forKey:@"A"];
    [hexDic setObject:@"1011" forKey:@"B"];
    [hexDic setObject:@"1100" forKey:@"C"];
    [hexDic setObject:@"1101" forKey:@"D"];
    [hexDic setObject:@"1110" forKey:@"E"];
    [hexDic setObject:@"1111" forKey:@"F"];
    NSMutableString *binaryString=[[NSMutableString alloc] init];
    for (int i=0; i<[hex length]; i++) {
        NSRange rage;
        rage.length = 1;
        rage.location = i;
        NSString *key = [hex substringWithRange:rage];
        NSString *temp2 = [NSString stringWithFormat:@"%@",[hexDic objectForKey:key]];
        binaryString = [NSString stringWithFormat:@"%@%@",[binaryString copy],temp2];
    }
    //NSLog(@"转化后的二进制为:%@",binaryString);
    return binaryString;
}
+ (NSString *)toDecimalSystemWithBinarySystem:(NSString *)binary
{
    int ll = 0 ;
    int  temp = 0 ;
    for (int i = 0; i < binary.length; i ++)
    {
        temp = [[binary substringWithRange:NSMakeRange(i, 1)] intValue];
        temp = temp * powf(2, binary.length - i - 1);
        ll += temp;
    }
    
    NSString * result = [NSString stringWithFormat:@"%d",ll];
    return result;
}



+ (unsigned char)getCheckCode:(unsigned char*)buffer withLen:(NSInteger)len {
    int res = 0;
    for (NSInteger i = 0; i < len; i++) {
        res += buffer[i];
    }
    res+=1;
    return res%256;
}




// 十六进制转换为普通字符串的。
+ (NSString *)stringFromHexString:(NSString *)hexString { //
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:4];
    NSLog(@"------字符串=======%@",unicodeString);
    return unicodeString;
    
    
}

// 普通字符串转换为十六进制的字符串
+ (NSString *)hexStringFromString:(NSString *)string {
    NSData *myD = [string dataUsingEncoding:NSUTF8StringEncoding];
    Byte *bytes = (Byte *)[myD bytes];
    NSString *hexStr=@"";
    for(int i=0;i<[myD length];i++) {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff]; //16进制数
        if([newHexStr length]==1) {
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        } else {
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
        }
    }
    return hexStr;
}


+ (NSString*)changeDataBufferToString:(unsigned char*)dataBuffer withLenght:(NSInteger)len  {
    NSString* aString = [NSString string];
    for (NSInteger index = 0; index < len; index++) {
        unsigned char byte = dataBuffer[index];
        unsigned char hByte = (byte & 0xf0) >> 4;
        unsigned char lByte = (byte & 0x0f);
        aString = [aString stringByAppendingFormat:@"%1x%1x",hByte,lByte];
    }
    return aString;
}
+(Boolean) isInCurrentTime:(NSDictionary*) dic
//
{
    NSDate* compareDate = [dic objectForKey:@"ReceivingDate"];
    NSTimeInterval  timeInterval = [compareDate timeIntervalSinceNow];
    timeInterval = abs(timeInterval);
    if (timeInterval < 2) {//2秒内
        return YES;
    }
    return  false;
}
+(int)conversionWeekDay:(int) weekDay{
    int result = -1;
    switch (weekDay) {
        case 1:
            result = 7;
            break;
        case 2:
            result = 1;
            break;
        case 3:
            result = 2;
            break;
        case 4:
            result = 3;
            break;
        case 5:
            result = 4;
            break;
        case 6:
            result = 5;
            break;
        case 7:
            result = 6;
            break;
        default:
            break;
    }
    
    return result;
}

+ (UIImage*) createImageWithColor: (UIColor*) color
{
    CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

/**
 * 计算CRC16校验
 *
 * @param data
 *            需要计算的数组
 * @param offset
 *            起始位置
 * @param len
 *            长度
 * @return CRC16校验值
 */
+(unsigned short) calcCrc16:(NSData*) data {
    return  [self calcCrc16 :data andOffSet:0 withLen:(int)data.length andPrevAL:0xffff ];
}





static const unsigned char crc16_tab_h[] = {  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,
    0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,
    0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,
    0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,
    0x80,  0x41,  0x00,  0xC1,  0x81,  0x40,  0x01,  0xC0,  0x80,  0x41,  0x01,  0xC0,  0x80,  0x41,  0x00,  0xC1,  0x81,  0x40 };



static const unsigned char crc16_tab_l[] = {  0x00,  0xC0,  0xC1,  0x01,  0xC3,  0x03,  0x02,  0xC2,  0xC6,  0x06,  0x07,  0xC7,  0x05,  0xC5,  0xC4,  0x04,  0xCC,  0x0C,  0x0D,  0xCD,  0x0F,  0xCF,  0xCE,  0x0E,  0x0A,  0xCA,  0xCB,  0x0B,  0xC9,  0x09,  0x08,  0xC8,  0xD8,  0x18,  0x19,  0xD9,  0x1B,  0xDB,  0xDA,  0x1A,  0x1E,  0xDE,  0xDF,  0x1F,  0xDD,  0x1D,  0x1C,  0xDC,  0x14,  0xD4,  0xD5,  0x15,  0xD7,  0x17,  0x16,  0xD6,  0xD2,  0x12,
    0x13,  0xD3,  0x11,  0xD1,  0xD0,  0x10,  0xF0,  0x30,  0x31,  0xF1,  0x33,  0xF3,  0xF2,  0x32,  0x36,  0xF6,  0xF7,  0x37,  0xF5,  0x35,  0x34,  0xF4,  0x3C,  0xFC,  0xFD,  0x3D,  0xFF,  0x3F,  0x3E,  0xFE,  0xFA,  0x3A,  0x3B,  0xFB,  0x39,  0xF9,  0xF8,  0x38,  0x28,  0xE8,  0xE9,  0x29,  0xEB,  0x2B,  0x2A,  0xEA,  0xEE,  0x2E,  0x2F,  0xEF,  0x2D,  0xED,  0xEC,  0x2C,  0xE4,  0x24,  0x25,  0xE5,  0x27,  0xE7,
    0xE6,  0x26,  0x22,  0xE2,  0xE3,  0x23,  0xE1,  0x21,  0x20,  0xE0,  0xA0,  0x60,  0x61,  0xA1,  0x63,  0xA3,  0xA2,  0x62,  0x66,  0xA6,  0xA7,  0x67,  0xA5,  0x65,  0x64,  0xA4,  0x6C,  0xAC,  0xAD,  0x6D,  0xAF,  0x6F,  0x6E,  0xAE,  0xAA,  0x6A,  0x6B,  0xAB,  0x69,  0xA9,  0xA8,  0x68,  0x78,  0xB8,  0xB9,  0x79,  0xBB,  0x7B,  0x7A,  0xBA,  0xBE,  0x7E,  0x7F,  0xBF,  0x7D,  0xBD,  0xBC,  0x7C,  0xB4,  0x74,
    0x75,  0xB5,  0x77,  0xB7,  0xB6,  0x76,  0x72,  0xB2,  0xB3,  0x73,  0xB1,  0x71,  0x70,  0xB0,  0x50,  0x90,  0x91,  0x51,  0x93,  0x53,  0x52,  0x92,  0x96,  0x56,  0x57,  0x97,  0x55,  0x95,  0x94,  0x54,  0x9C,  0x5C,  0x5D,  0x9D,  0x5F,  0x9F,  0x9E,  0x5E,  0x5A,  0x9A,  0x9B,  0x5B,  0x99,  0x59,  0x58,  0x98,  0x88,  0x48,  0x49,  0x89,  0x4B,  0x8B,  0x8A,  0x4A,  0x4E,  0x8E,  0x8F,  0x4F,  0x8D,  0x4D,
    0x4C,  0x8C,  0x44,  0x84,  0x85,  0x45,  0x87,  0x47,  0x46,  0x86,  0x82,  0x42,  0x43,  0x83,  0x41,  0x81,  0x80,  0x40 };
/**
 * 计算CRC16校验
 *
 * @param data
 *            需要计算的数组
 * @param offset
 *            起始位置
 * @param len
 *            长度
 * @param preval
 *            之前的校验值
 * @return CRC16校验值
 */
+(unsigned short) calcCrc16:(NSData*) data andOffSet:(int) offset withLen: (int) len andPrevAL:(int) preval {
    int ucCRCHi = (preval & 0xff00) >> 8;
    int ucCRCLo = preval & 0x00ff;
    int iIndex;
    for (int i = 0; i < len; ++i) {
        
        Byte *testByte = (Byte *)[data bytes];
        iIndex = (ucCRCLo ^ testByte[offset + i]) & 0x00ff;
        ucCRCLo = ucCRCHi ^ crc16_tab_h[iIndex];
        ucCRCHi = crc16_tab_l[iIndex];
    }
    return ((ucCRCHi & 0x00ff) << 8) | (ucCRCLo & 0x00ff) & 0xffff;
}


+(NSData*) commandMutlPackaging:(int) addr withFun:(int) fun withAddSH:(int) addrStartH  withAddSL:(int)addrStartl  WithCMD:(NSString*)pswd{
    
    
    
    unsigned char dataBuffer[14] = {addr,fun,addrStartH,addrStartl,0x00,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
    
    NSData *testData = [pswd dataUsingEncoding: NSUTF8StringEncoding];
    Byte *tpswdByte = (Byte *)[testData bytes];
    
    
    dataBuffer[6] = tpswdByte[0];
    dataBuffer[7] = tpswdByte[1];
    dataBuffer[8] = tpswdByte[2];
    dataBuffer[9] = tpswdByte[3];
    dataBuffer[10] = tpswdByte[4];
    dataBuffer[11] = tpswdByte[5];
    
    
    NSRange monthRang = NSMakeRange(0, 12);
    NSData *personData = [[NSData alloc] initWithBytes:dataBuffer length:sizeof(dataBuffer)/sizeof(dataBuffer[0])];
    personData = [personData subdataWithRange:monthRang];
    
    
    unsigned short checkKey =  [self calcCrc16:personData];
    dataBuffer[13] =(char)((checkKey&0xff00)>>8);
    dataBuffer[12] = (char)(checkKey&0xff);
    NSData *commandData = [[NSData alloc] initWithBytes:dataBuffer length:sizeof(dataBuffer)/sizeof(dataBuffer[0])];
    return  commandData;
}


+(NSData*) commandPackaging:(int) addr withFun:(int) fun withAddSH:(int) addrStartH  withAddSL:(int)addrStartl  WithAddrEH:(int) addrEndH andAddrEL:(int) addrEndL{
    
    unsigned char dataBuffer[8] = {addr,fun,addrStartH,addrStartl,addrEndH,addrEndL,0x00,0x00};
    NSRange monthRang = NSMakeRange(0, 6);
    NSData *personData = [[NSData alloc] initWithBytes:dataBuffer length:sizeof(dataBuffer)/sizeof(dataBuffer[0])];
    personData = [personData subdataWithRange:monthRang];
    unsigned short checkKey =  [self calcCrc16:personData];
    dataBuffer[7] =(char)((checkKey&0xff00)>>8);
    dataBuffer[6] = (char)(checkKey&0xff);
    NSData *commandData = [[NSData alloc] initWithBytes:dataBuffer length:sizeof(dataBuffer)/sizeof(dataBuffer[0])];
    return  commandData;
}
+ (NSString *)convertDataToHexStr:(NSData *)data {
    if (!data || [data length] == 0) {
        return @"";
    }
    NSMutableString *string = [[NSMutableString alloc] initWithCapacity:[data length]];
    
    [data enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange,BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i =0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) &0xff];
            if ([hexStr length] == 2) {
                [string appendString:hexStr];
            } else {
                [string appendFormat:@"0%@", hexStr];
            }
        }
    }];
    
    return string;
}




+ (Boolean) isLanguageCN
{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    NSString * preferredLang = [allLanguages objectAtIndex:0];
    NSLog(@"当前语言:%@", preferredLang);
    if([preferredLang hasPrefix: @"zh"] )
    {
        return YES;;
    }
    return NO;
}
+ (Boolean) isLanguageRuss
{
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    NSString * preferredLang = [allLanguages objectAtIndex:0];
    NSLog(@"当前语言:%@", preferredLang);
    if([preferredLang hasPrefix: @"ru"] )
    {
        return YES;;
    }
    return NO;
}



#pragma mark 解析蓝牙接收到的数据
-(void) parseLocalDataWithDeviceID:(NSString*)result withDevice:(NSString*)deviceID{
    @synchronized(self) {
        if(result == nil)
            return;
        NSMutableString *commandStr = [_recvLocalCommandStrDic objectForKey:deviceID];
        if (commandStr==nil) {
            commandStr = [[NSMutableString alloc] initWithString:@""];
        }
        NSLog(@"----------------------------MQW接收到设备：%@ 数据：%@",deviceID,result);
        [commandStr appendString:result];
        //NSLog(@"----------------------------待处理设备：%@ 数据：%@",deviceID,commandStr);
        [_recvLocalCommandStrDic setObject:commandStr forKey:deviceID];
        
        NSMutableDictionary*redDic = [[NSMutableDictionary alloc]initWithCapacity:0];
        [redDic setValue:@(CMD_OBJ_RECV) forKey:@"OperationType"];
        [redDic setValue:result forKey:@"OBJ_DATA"];
        [redDic setValue:deviceID forKey:@"deviceID"];
        [[NSNotificationCenter defaultCenter] postNotificationName:kOnRecvPipeDataALL object:self userInfo:redDic];
        
        //LD2451_13790016
        if([deviceID containsString:@"LD2451"] || [deviceID containsString:@"HLK-LD2450"] || [deviceID containsString:@"HLK-6002"] || [deviceID containsString:@"tSample"] || [deviceID containsString:@"HMD02"]){
            
            
        }else{
            //2410/2411系列解析
            [DeviceInfo sharedClient].remainStr = @"";
            [self doParseHLK2411_2410:commandStr withDevice:deviceID];
            
        }
    }
}


-(void)doParseHLK2411_2410:(NSString *)cmdStr withDevice:(NSString*)deviceID{
    Boolean isFindHeader = NO;
    NSMutableString*commandStr = [[NSMutableString alloc]initWithString:cmdStr];
    while (commandStr.length > 0) {
//        if (self.isLogMode) {//日志模式
//            WS(weakSelf);
//            NSLog(@"处理日志数据 %@",commandStr);
//            [self handleLogData:commandStr];
//            return;
//        }
        
        NSRange start = [commandStr rangeOfString:COMMAND_REPOORT_HEAD];
        NSRange start1 = [commandStr rangeOfString:COMMAND_HEAD];
        if (start.length == 0  &&start1.length == 0 ) {
            isFindHeader = NO;
            break;
        }
        isFindHeader = YES;
        int startLoc = 0;
        int startLength = 0;
        int cmdType = CMD_SEND_BACK_RECV;
        NSString*endPackage =COMMAND_END;
        if (start1.length == 0 ) {
            //没有指令包，都是数据上报包
            endPackage = COMMAND_REPORT_END;
            cmdType = CMD_OBJ_RECV;
            startLoc = (int)start.location;
            startLength =  (int)start.length;
        }else{
            startLoc = (int)start1.location;
            startLength =   (int)start1.length;
        }
        
        [commandStr deleteCharactersInRange:NSMakeRange(0,startLoc)];
        [_recvLocalCommandStrDic setObject:commandStr forKey:deviceID];
        NSRange end   = [commandStr rangeOfString:endPackage];
        if (end.length == 0 ) {
            break;
        }
        NSInteger loc    = startLength;
        NSInteger length = end.location-loc;
        NSString*resultValue =  [commandStr substringWithRange:NSMakeRange(loc,length)];
        
        
        NSMutableString *commandStrT = [[NSMutableString alloc] initWithString:resultValue];
        int recvCmdLength = (int)commandStrT.length/2-2;
      
        
        NSString* verT = [NSString stringWithFormat:@"%@%@",[commandStrT substringWithRange:NSMakeRange(2,2)],[commandStrT substringWithRange:NSMakeRange(0,2)]];
        int cmdLength = (int)strtoul([ verT UTF8String],0,16);
        if (recvCmdLength == cmdLength) {
            //防止崩溃
            if (commandStr.length < startLoc + end.location+end.length) {
                return;
            }
            [commandStr deleteCharactersInRange:NSMakeRange(startLoc,end.location+end.length)];
            [_recvLocalCommandStrDic setObject:commandStr forKey:deviceID];
//                NSLog(@"----------------------------完整数据:%@",commandStrT);
//                NSLog(@"----------------------------剩余待处理数据：%@",commandStr);
             //解析数据
            
            NSMutableDictionary*redDic = [[NSMutableDictionary alloc]initWithCapacity:0];
            [redDic setValue:@(cmdType) forKey:@"commandType"];
            [redDic setValue:commandStrT forKey:@"recvData"];
            [redDic setValue:deviceID forKey:@"deviceID"];

            [self  doParseData:redDic];

        }
        isFindHeader = NO;
        continue;
    }
    

}
-(void)doParseData:(NSDictionary*)recDic{
    int type = [recDic[@"commandType"] intValue];
    NSString*commandStrT =recDic[@"recvData"];
    NSString*deviceID =recDic[@"deviceID"];
    NSDictionary*resDic = nil;
    switch (type ) {
        case CMD_OBJ_RECV://目标数据上报
        {
            //NSLog(@"设备主动上报...............");
            
            if([deviceID containsString:@"HLK-LD2412"]){
                resDic = [self doParseObjWork_2412:commandStrT withDeviceID:deviceID];
            }else{
                //2410/2411系列解析
                resDic = [self doParseObjWork:commandStrT withDeviceID:deviceID];
            }
            
         
        }
            break;
        case CMD_SEND_BACK_RECV://读写业务数据返回
        {
            //NSLog(@"读写业务数据返回:%@",commandStrT);
            if([deviceID containsString:@"HLK-LD2412"]){
                resDic = [self doParseConfigWork_2412:commandStrT withDeviceID:deviceID];
            }else{
                //2410/2411系列解析
                resDic = [self doParseConfigWork:commandStrT withDeviceID:deviceID];
            }
            
           
        }
            break;
        default:
            break;
    }
    if(resDic !=nil){
        NSMutableDictionary*redDic = [NSMutableDictionary dictionaryWithDictionary:resDic];
        [redDic setObject:recDic[@"recvData"] forKey:@"allData"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kOnRecvPipeData" object:self userInfo:redDic];
        
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"kOnRecvPipeData" object:self userInfo:resDic];
    }
   
}


-(NSDictionary*)doParseConfigWork_2412:(NSString*)cmd withDeviceID:(NSString*)deviceid{
    //0800 ff01 00000 1000000
    
    NSMutableDictionary*redDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    NSMutableDictionary*objDetel = [[NSMutableDictionary alloc]initWithCapacity:0];
    //命令字
    int b1 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(4,4)] UTF8String],0,16);
    int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
  
    Boolean isOK = b2==0?YES:NO;
    
    NSString*dataCmd = [cmd substringFromIndex:8];
    
    [objDetel setValue:dataCmd forKey:@"dataCmd"];
    [redDic setValue:@(b1) forKey:@"CMD_DATA_TYPE"];
    [redDic setValue:objDetel forKey:@"CMD_DATA"];
    [redDic setValue:@(isOK) forKey:@"isOK"];
    [redDic setValue:@(CMD_SEND_BACK_RECV) forKey:@"OperationType"];
    
    return redDic;
}




-(NSDictionary*)doParseConfigWork:(NSString*)cmd withDeviceID:(NSString*)deviceid{
    //f4f3f2f10d0002aa034b004f00006400005500f8f7f6f5
    
    NSMutableDictionary*redDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    NSMutableDictionary*objDetel = [[NSMutableDictionary alloc]initWithCapacity:0];
    //命令字
    int b1 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(4,4)] UTF8String],0,16);
    if (b1==0xff01) {
        
        NSLog(@"使能配置命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        // 使能配置命令
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xfe01) {
        //结束配置命令
        NSLog(@"结束配置命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
    }if (b1==0x6201) {
        // 工程模式开启命令
        NSLog(@"工程模式开启命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0x6301) {
        //工程模式关闭配置命令
        NSLog(@"工程模式关闭配置命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
    }else if (b1==0x6401) {
        //距离门灵敏度配置命令
        NSLog(@"距离门灵敏度配置命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
    }
    else if (b1==0xa201) {
        //恢复出厂配置命令
        NSLog(@"恢复出厂配置命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
    }else if (b1==0xa301) {
        NSLog(@"模块重启命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
    }else if (b1==0x6001) {
        NSLog(@"最大距离门与无人持续时间参数配置命令返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xc401) {
        //设置门限值返回
        if (cmd.length < 10) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,2)] UTF8String],0,16);
        Boolean isOK = (b2==0X01)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1 == 0xc600) {
        //主动上报有人无人
        NSLog(@"正在上报有人无人信息===%@",cmd);
        if (cmd.length < 10) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,2)] UTF8String],0,16);
        
        [objDetel setValue:@(b2) forKey:@"NoOneAndNoOne"];
    }
    else if (b1==0x6101) {
        //读取参数命令
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        int b3 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(12,2)] UTF8String],0,16);
        if(isOK &&  (b3 == 0xaa))
        {
            //增加判断预防断包导致崩溃
            if (cmd.length < 20) {
                return nil;
            }
            int maxGap = (int)strtoul([ [cmd substringWithRange:NSMakeRange(14,2)] UTF8String],0,16);//最大距离门数
            int maxGapMotionCofig = (int)strtoul([ [cmd substringWithRange:NSMakeRange(16,2)] UTF8String],0,16);//配置最大运动距离门
            int maxGapStaticCofig = (int)strtoul([ [cmd substringWithRange:NSMakeRange(18,2)] UTF8String],0,16);//配置最大静止距离门
            //增加判断预防断包导致崩溃
            if (cmd.length < 20+(maxGapMotionCofig+1)*2+(maxGapStaticCofig+1)*2) {
                return nil;
            }
            //运动灵敏度
            NSMutableArray*motionSensitivity = [[NSMutableArray alloc]initWithCapacity:0];
            for (int i=0; i<=maxGapMotionCofig; i++) {
                int sensitivity = (int)strtoul([ [cmd substringWithRange:NSMakeRange(20+i*2,2)] UTF8String],0,16);//配置最大静止距离门
               
                float fSensitivity = sensitivity*1.0;
                [motionSensitivity addObject:@(fSensitivity)];
                
            }
            //此处取固定位置开始取静止灵敏度,不根据当前距离门数量取
            NSUInteger startindex = 20+(maxGap+1)*2;
            //静止灵敏度
            NSMutableArray*staticSensitivity = [[NSMutableArray alloc]initWithCapacity:0];
            for (int i=0; i<=maxGapStaticCofig; i++) {
                int sensitivity = (int)strtoul([ [cmd substringWithRange:NSMakeRange(startindex+i*2,2)] UTF8String],0,16);//配置最大静止距离门
//                NSLog(@"静止灵敏度===========%@",[cmd substringWithRange:NSMakeRange(startindex+i*2,2)]);
                float fSensitivity = sensitivity*1.0;
                [staticSensitivity addObject:@(fSensitivity)];
                
            }
//            startindex = startindex+(maxGap+1)*2;
            
            //无人持续时间  此处取固定位置作为无人持续时间，不根据当前距离门数量取
            NSString* verT = [NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(cmd.length-2,2)],[cmd substringWithRange:NSMakeRange(cmd.length-4,2)]];
            int duration = (int)strtoul([verT UTF8String],0,16);
            
            [objDetel setValue:@(maxGap) forKey:@"maxGap"];
            [objDetel setValue:@(maxGapMotionCofig) forKey:@"maxGapMotionCofig"];
            [objDetel setValue:@(maxGapStaticCofig) forKey:@"maxGapStaticCofig"];
            
            [objDetel setValue:motionSensitivity forKey:@"motionSensitivity"];
            [objDetel setValue:staticSensitivity forKey:@"staticSensitivity"];
            [objDetel setValue:@(duration) forKey:@"duration"];
            
        }
    }else if (b1==0xa001) {
        //固件版本信息返回
        NSLog(@"固件版本信息返回：%@",cmd);
        if (cmd.length < 20) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        NSString *verStr = [NSString stringWithFormat:@"%d.%@.%@%@%@%@",[[cmd substringWithRange:NSMakeRange(18,2)] intValue],[cmd substringWithRange:NSMakeRange(16,2)],[cmd substringWithRange:NSMakeRange(cmd.length-2,2)],[cmd substringWithRange:NSMakeRange(cmd.length-4,2)],[cmd substringWithRange:NSMakeRange(cmd.length-6,2)],[cmd substringWithRange:NSMakeRange(cmd.length-8,2)]];
        [objDetel setValue:verStr forKey:@"verStr"];
    }else if (b1==0xab01) {
        //距离门分辨率返回
        NSLog(@"距离门分辨率返回：%@",cmd);
        if (cmd.length < 14) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        [objDetel setValue:[cmd substringWithRange:NSMakeRange(12,2)] forKey:@"resolution"];
    }else if (b1==0xaa01) {
        //设置距离门分辨率返回
        NSLog(@"设置距离门分辨率返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }    else if (b1==0xa801) {
        //校验密码
        NSLog(@"校验密码返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xa901) {
        //设置密码
        NSLog(@"设置密码返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xa101) {
        //设置波特率
        NSLog(@"设置波特率返回：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xad01) {
        //设置光敏度
        NSLog(@"设置光敏度：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xae01) {
        //查询光敏度
        NSLog(@"查询光敏度：%@",cmd);
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        [objDetel setValue:[cmd substringWithRange:NSMakeRange(cmd.length-8, 8)] forKey:@"guangminData"];
    }else if (b1==0xc501) {
        //查询门限值
        NSLog(@"查询门限值:%@",cmd);
        if (cmd.length < 14) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(6,2)] UTF8String],0,16);
        Boolean isOK = (b2==0X01)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
        int shangXian = (int)strtoul([ [cmd substringWithRange:NSMakeRange(8,2)] UTF8String],0,16);
        int xiaXian = (int)strtoul([ [cmd substringWithRange:NSMakeRange(12,2)] UTF8String],0,16);
        [objDetel setValue:@(shangXian) forKey:@"shangXian"];
        [objDetel setValue:@(xiaXian) forKey:@"xiaXian"];
    }else if (b1==0x7301) {
        //2411-S 雷达当前的配置参数。
        NSLog(@"2411-S 雷达当前的配置参数:%@",cmd);
        if (cmd.length < 32) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(6,2)] UTF8String],0,16);
        Boolean isOK = (b2==0X01)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        
        //运动最小
        int startMovement = (int)strtoul([[NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(18,2)],[cmd substringWithRange:NSMakeRange(16,2)]] UTF8String],0,16);
        //运动最大
        int endMovement = (int)strtoul([[NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(14,2)],[cmd substringWithRange:NSMakeRange(12,2)]] UTF8String],0,16);
        [objDetel setValue:@(startMovement) forKey:@"startMovement"];
        [objDetel setValue:@(endMovement) forKey:@"endMovement"];
        
        //微动最小
        int startFretting = (int)strtoul([[NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(26,2)],[cmd substringWithRange:NSMakeRange(24,2)]] UTF8String],0,16);
        //微动最大
        int endFretting = (int)strtoul([[NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(22,2)],[cmd substringWithRange:NSMakeRange(20,2)]] UTF8String],0,16);
        
        [objDetel setValue:@(startFretting) forKey:@"startFretting"];
        [objDetel setValue:@(endFretting) forKey:@"endFretting"];
        
        //无人持续时间
        int noPeopleTime = (int)strtoul([[NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(30,2)],[cmd substringWithRange:NSMakeRange(28,2)]] UTF8String],0,16);
        [objDetel setValue:@(noPeopleTime) forKey:@"noPeopleTime"];
    }else if (b1==0x6701) {
        //设置2411-S参数
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xb501) {
        //当前已储存的日志数据长度
        if (cmd.length < 18) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
        int logLength = (int)strtoul([[NSString stringWithFormat:@"%@%@%@%@",[cmd substringWithRange:NSMakeRange(18,2)],[cmd substringWithRange:NSMakeRange(16,2)],[cmd substringWithRange:NSMakeRange(14,2)],[cmd substringWithRange:NSMakeRange(12,2)]] UTF8String],0,16);
        [objDetel setObject:@(logLength) forKey:@"logLength"];
    }else if (b1==0xb601) {
        //储存的日志数据
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xb701) {
        //清除日志数据
        NSLog(@"+++++++++清除日志数据回复");
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0xb801) {
        //日志存储功能回复
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }else if (b1==0x0b01) {
        //日志存储功能回复
        if (cmd.length < 12) {
            return nil;
        }
        int b2 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(8,4)] UTF8String],0,16);
        Boolean isOK = (b2==0X00)?YES:NO;
        [objDetel setValue:@(isOK) forKey:@"isOK"];
    }
    
    
    [redDic setValue:@(b1) forKey:@"CMD_DATA_TYPE"];
    [redDic setValue:objDetel forKey:@"CMD_DATA"];
    [redDic setValue:@(CMD_SEND_BACK_RECV) forKey:@"OperationType"];
    
    return redDic;
}


-(NSDictionary*)doParseObjWork_2412:(NSString*)cmd withDeviceID:(NSString*)deviceid{
    //0b00  02  aa000000000000005500
    NSMutableDictionary*redDic = [[NSMutableDictionary alloc]initWithCapacity:0];
 
    NSMutableDictionary*objDetel = [[NSMutableDictionary alloc]initWithCapacity:0];
    //数据类型 0x01 工程模式数据  0x02 目标基本信息数据
    int b1 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(4,2)] UTF8String],0,16);
    
    // 目标基本信息数据,正常工作模式下
    //数据头部
    int b2 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(6,2)] UTF8String],0,16);
    if (b2 !=0xaa) {
        return nil;
    }
    //目标状态 0x00:无目标，0x01:运动目标，0x02:静止目标，0x03：运动&静止目标
    int b3 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(8,2)] UTF8String],0,16);
    
    //运动目标距离厘米
    NSString* verT = [NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(12,2)],[cmd substringWithRange:NSMakeRange(10,2)]];
    int b4 = (int)strtoul([verT UTF8String],0,16);
    //运动目标能量值
    int b5 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(14,2)] UTF8String],0,16);
    
    
    
    //静止目标距离厘米
    verT = [NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(18,2)],[cmd substringWithRange:NSMakeRange(16,2)]];
    int b6 = (int)strtoul([verT UTF8String],0,16);
    //静止目标能量值
    int b7 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(20,2)] UTF8String],0,16);

    [objDetel setValue:@(b1) forKey:@"b1"];
    [objDetel setValue:@(b3) forKey:@"b3"];
    [objDetel setValue:@(b4) forKey:@"b4"];
    [objDetel setValue:@(b5) forKey:@"b5"];
    [objDetel setValue:@(b6) forKey:@"b6"];
    [objDetel setValue:@(b7) forKey:@"b7"];

    if (b1==0x01) {
        NSString* cmdData = [cmd substringWithRange:NSMakeRange(22, cmd.length-26)];
        //0d0d 000364642e000000000000020103   00646464645064351b11120a0303  8a00
        //2900 01 aa 03 9600 64 9c00 64 0d0d 00 00 64040000000000000000010300646464646464646441522c1111   55f1
        // 最大运动距离门N
        int motionGataMax =(int)strtoul([[cmdData substringWithRange:NSMakeRange(0,2)] UTF8String],0,16);
        int staticGataMax =(int)strtoul([[cmdData substringWithRange:NSMakeRange(2,2)] UTF8String],0,16);
      
        [objDetel setValue:@(motionGataMax) forKey:@"motionGataMax"];
        [objDetel setValue:@(staticGataMax) forKey:@"staticGataMax"];
        
 
        //跳过第一个距离门
        NSString* motionStr = [cmdData substringWithRange:NSMakeRange(6 - 2, motionGataMax*2 + 2)];
        //跳过第一个距离门（改为不跳过）
        NSString* staticStr = [cmdData substringWithRange:NSMakeRange(6+motionGataMax*2 + 2 - 2,staticGataMax*2 + 2)];

        int gateNum =cmdData.length-4;
        if(gateNum == (motionGataMax+1)*2*2)
        {
            NSLog(@"不支持光敏的固件...........");
            [objDetel setValue:@(-1) forKey:@"Luminous"];
        }else if(gateNum == (motionGataMax+1)*2*2+4) {
            
            NSLog(@"支持光敏的固件...........");
            
            int luminous =(int)strtoul([[cmdData substringWithRange:NSMakeRange(cmdData.length-4,2)] UTF8String],0,16);
            [objDetel setValue:@(luminous) forKey:@"Luminous"];
        }
        
    
        
        //运动距离门能量值
        NSMutableArray*motionEnergyArray = [[NSMutableArray alloc]initWithCapacity:0];
        for(int i= 0;i<motionGataMax + 1;i++){
            int energy = (int)strtoul([ [motionStr substringWithRange:NSMakeRange(i*2,2)] UTF8String],0,16);
            [motionEnergyArray addObject:@(energy)];
        }
        [objDetel setValue:motionEnergyArray forKey:@"motionEnergyArray"];
        

        //静止距离门能量值
        NSMutableArray*staticEnergyArray = [[NSMutableArray alloc]initWithCapacity:0];
        for(int i= 0;i<staticGataMax + 1;i++){
            int energy = (int)strtoul([ [staticStr substringWithRange:NSMakeRange(i*2,2)] UTF8String],0,16);
            [staticEnergyArray addObject:@(energy)];
            
        }
        [objDetel setValue:staticEnergyArray forKey:@"staticEnergyArray"];
    }
    [redDic setValue:@(b1) forKey:@"OBJ_DATA_TYPE"];
    [redDic setValue:objDetel forKey:@"OBJ_DATA"];
    [redDic setValue:@(CMD_OBJ_RECV) forKey:@"OperationType"];
    
    return redDic;
}

-(NSDictionary*)doParseObjWork:(NSString*)cmd withDeviceID:(NSString*)deviceid{
    //0b0002aa020000000901135500
    
    NSMutableDictionary*redDic = [[NSMutableDictionary alloc]initWithCapacity:0];
 
    NSMutableDictionary*objDetel = [[NSMutableDictionary alloc]initWithCapacity:0];
    //数据类型
    int b1 =(int)strtoul([ [cmd substringWithRange:NSMakeRange(4,2)] UTF8String],0,16);
    
    // 目标基本信息数据,正常工作模式下
    //数据头部
    int b2 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(6,2)] UTF8String],0,16);
    if (b2 !=0xaa) {
        return nil;
    }
    //目标状态 0x00:无目标，0x01:运动目标，0x02:静止目标，0x03：运动&静止目标
    int b3 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(8,2)] UTF8String],0,16);
    
    //运动目标距离厘米
    NSString* verT = [NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(12,2)],[cmd substringWithRange:NSMakeRange(10,2)]];
    int b4 = (int)strtoul([verT UTF8String],0,16);
    //运动目标能量值
    int b5 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(14,2)] UTF8String],0,16);
    
    
    
    //静止目标距离厘米
    verT = [NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(18,2)],[cmd substringWithRange:NSMakeRange(16,2)]];
    int b6 = (int)strtoul([verT UTF8String],0,16);
    //运动目标能量值
    int b7 = (int)strtoul([ [cmd substringWithRange:NSMakeRange(20,2)] UTF8String],0,16);
    
    
    //探测距离（厘米
    verT = [NSString stringWithFormat:@"%@%@",[cmd substringWithRange:NSMakeRange(24,2)],[cmd substringWithRange:NSMakeRange(22,2)]];
    int b8 = (int)strtoul([verT UTF8String],0,16);
    
    [objDetel setValue:@(b3) forKey:@"b3"];
    [objDetel setValue:@(b4) forKey:@"b4"];
    [objDetel setValue:@(b5) forKey:@"b5"];
    [objDetel setValue:@(b6) forKey:@"b6"];
    [objDetel setValue:@(b7) forKey:@"b7"];
    [objDetel setValue:@(b8) forKey:@"b8"];
    

    if (b1==0x01) {
        // 工程模式数据，出了基本数据外，追加额外数据
        //数据头部
        //最大运动距离门N
        int maxGapMotionCofig = (int)strtoul([ [cmd substringWithRange:NSMakeRange(26,2)] UTF8String],0,16);
        [objDetel setValue:@(maxGapMotionCofig) forKey:@"maxGapMotionCofig"];
        
        int maxGapStaticCofig = (int)strtoul([ [cmd substringWithRange:NSMakeRange(28,2)] UTF8String],0,16);
        [objDetel setValue:@(maxGapStaticCofig) forKey:@"maxGapStaticCofig"];
        
        //运动距离门能量值
        NSMutableArray*motionEnergyArray = [[NSMutableArray alloc]initWithCapacity:0];
        for(int i= 0;i<=maxGapMotionCofig;i++){
            int energy = (int)strtoul([ [cmd substringWithRange:NSMakeRange(30+i*2,2)] UTF8String],0,16);
            [motionEnergyArray addObject:@(energy)];
        }
        [objDetel setValue:motionEnergyArray forKey:@"motionEnergyArray"];
        int start =30+(maxGapMotionCofig+1)*2;
        //静止距离门能量值
        NSMutableArray*staticEnergyArray = [[NSMutableArray alloc]initWithCapacity:0];
        for(int i= 0;i<=maxGapStaticCofig;i++){
            int energy = (int)strtoul([ [cmd substringWithRange:NSMakeRange(start+i*2,2)] UTF8String],0,16);
            [staticEnergyArray addObject:@(energy)];
            
        }
        [objDetel setValue:staticEnergyArray forKey:@"staticEnergyArray"];
        
        start = start+(maxGapMotionCofig+1)*2;
        
        //这里取光敏值
        int photosensitive = (int)strtoul([[cmd substringWithRange:NSMakeRange(start,2)] UTF8String],0,16);
        [objDetel setValue:@(photosensitive) forKey:@"guangmin"];
        
    }
    [redDic setValue:@(b1) forKey:@"OBJ_DATA_TYPE"];
    [redDic setValue:objDetel forKey:@"OBJ_DATA"];
    [redDic setValue:@(CMD_OBJ_RECV) forKey:@"OperationType"];
    
    return redDic;
}


-(NSData*)sendCMDToDevice:(NSString*)cmdType withCmdData:(NSString*)cmdData{
    
    NSMutableString*cmd =[[NSMutableString alloc]initWithString:COMMAND_HEAD];
    //长度
    int cmdLength = (int)(cmdType.length+cmdData.length)/2;
    int number =  NSSwapHostShortToBig(cmdLength);
    [cmd appendString:[NSString stringWithFormat:@"%04x",number]];
    [cmd appendString:cmdType];
    [cmd appendString:cmdData];
    [cmd appendString:COMMAND_END];
    
    return [DeviceInfo hexToData:cmd];
}



+ (NSData*)hexToData:(NSString *)hexString {
    
    NSUInteger len = hexString.length / 2;
    const char *hexCode = [hexString UTF8String];
    char * bytes = (char *)malloc(len);
    
    char *pos = (char *)hexCode;
    for (NSUInteger i = 0; i < hexString.length / 2; i++) {
        sscanf(pos, "%2hhx", &bytes[i]);
        pos += 2 * sizeof(char);
    }
    
    NSData * data = [[NSData alloc] initWithBytes:bytes length:len];
    
    free(bytes);
    return data;
}



//颜色转图片
+(UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}




/**
 *
 * 转换byte数组为Char(小端)
 *
 * @return
 *
 * @note 数组长度至少为2，按小端方式转换
 *
 */

+(int) Bytes2Char_LE:(NSData*)bytes{
    if (bytes.length < 2)
        return (char) -1;

    Byte *testByte = (Byte *)[bytes bytes];
    
    int iRst = (testByte[0] & 0xFF);
    iRst |= (testByte[1] & 0xFF) << 8;
    return iRst;

}

@end
