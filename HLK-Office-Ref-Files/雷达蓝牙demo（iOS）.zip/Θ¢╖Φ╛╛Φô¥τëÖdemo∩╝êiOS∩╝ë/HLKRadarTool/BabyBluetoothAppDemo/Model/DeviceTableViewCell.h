//
//  DeviceTableViewCell.h
//  BabyBluetoothAppDemo
//
//  Created by mqw on 2020/5/31.
//  Copyright © 2020 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^EditNameBlock) (void);

@interface DeviceTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *connectState;
@property (weak, nonatomic) IBOutlet UILabel *versionLabel;
@property (nonatomic, strong) EditNameBlock editBlock;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftContent;
@property (weak, nonatomic) IBOutlet UIButton *selectButton;



@end

NS_ASSUME_NONNULL_END
