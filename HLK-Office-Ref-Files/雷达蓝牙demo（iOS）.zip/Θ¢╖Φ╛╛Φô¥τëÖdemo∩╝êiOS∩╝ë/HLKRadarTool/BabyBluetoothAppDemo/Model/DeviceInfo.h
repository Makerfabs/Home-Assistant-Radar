//
//  DeviceInfo.h
//  Qkeeper
//
//  Created by mqw on 15/11/9.
//  Copyright © 2015年 mqw. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

/** 包头 */
#define  COMMAND_REPOORT_HEAD @"f4f3f2f1"
/** 包尾 */
#define COMMAND_REPORT_END    @"f8f7f6f5"

/** 包头 */
#define  COMMAND_HEAD @"fdfcfbfa"
/** 包尾 */
#define COMMAND_END    @"04030201"

#define  CMD_OBJ_RECV  0
#define  CMD_SEND_BACK_RECV  1



#pragma mark  设备工作状态
enum DeviceWorkStatuesEnum {
    DeviceWorkStatues_PowerOff  =0,//关机
    DeviceWorkStatues_Stop,//停止
    DeviceWorkStatues_Pause,//暂停
    DeviceWorkStatues_Wroking,//工作
};

@interface DeviceInfo : NSObject
@property (nonatomic, assign) int workState;                    //开关机状态,0：关机, 1：停止 2：暂停 3：工作
@property (nonatomic, assign) int airPumpState;                 //气泵状态,0关闭 1打开
@property (nonatomic, assign) int fanState;                     //风扇状态,0关闭 1打开
@property (nonatomic, assign) int essentialOilState;            //精油状态,0正常 1缺少
@property (nonatomic, assign) int WorkingPeriod;                //当前工作时间段: 1~3
@property (nonatomic, assign) int densityGears;                 //当前浓度档位:1~18
@property (nonatomic, strong) NSString* currentTime;            //设备时间

@property (nonatomic, assign) BOOL isLogMode;//是否进入日志模式
@property (nonatomic, strong) NSString *remainStr;//日志模式 请求数据多余部分

@property (nonatomic, strong) NSString *remainStr_6002;

@property (nonatomic,strong) NSMutableDictionary* recvLocalCommandStrDic;

+ (instancetype)sharedClient ;
//包括工作时间、暂停时间,浓度类型

+ (NSString *)convertDataToHexStr:(NSData *)data ;

+ (NSString *)toDecimalSystemWithBinarySystem:(NSString *)binary;
+ (unsigned char)getCheckCode:(unsigned char*)buffer withLen:(NSInteger)len;
+ (NSString*)changeDataBufferToString:(unsigned char*)dataBuffer withLenght:(NSInteger)len ;
+(NSString *)getBinaryByhex:(NSString *)hex;

+(Boolean) isInCurrentTime:(NSDictionary*) dic;
+(int)conversionWeekDay:(int) weekDay;

+ (UIImage*) createImageWithColor: (UIColor*) color;


+(NSData*) commandPackaging:(int) addr withFun:(int) fun withAddSH:(int) addrStartH  withAddSL:(int)addrStartl  WithAddrEH:(int) addrEndH andAddrEL:(int) addrEndL;

+(NSData*) commandMutlPackaging:(int) addr withFun:(int) fun withAddSH:(int) addrStartH  withAddSL:(int)addrStartl  WithCMD:(NSString*)pswd;

+ (NSString *)stringFromHexString:(NSString *)hexString ;
+ (NSString *)hexStringFromString:(NSString *)string ;


+ (Boolean) isLanguageCN;
+ (Boolean) isLanguageRuss;
+ (NSData*)hexToData:(NSString *)hexString ;



-(NSData*)sendCMDToDevice:(NSString*)cmdType withCmdData:(NSString*)cmdData;

-(void) parseLocalDataWithDeviceID:(NSString*)result withDevice:(NSString*)deviceID;
-(void)doParse:(NSString*)cmd;

+(NSString*)addString:(NSString*)string Length:(NSInteger)length OnString:(NSString*)str;

+(UIImage *)imageWithColor:(UIColor *)color;


+(int) Bytes2Char_LE:(NSData*)bytes;

/// 6002B校验和计算
/// - Parameters:
///   - data: <#data description#>
///   - len: <#len description#>
unsigned char getCksum(unsigned char *data, unsigned char len);
@end
