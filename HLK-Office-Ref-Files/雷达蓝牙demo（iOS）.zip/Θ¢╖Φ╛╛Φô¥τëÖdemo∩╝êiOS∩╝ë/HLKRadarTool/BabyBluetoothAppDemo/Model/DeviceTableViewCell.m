//
//  DeviceTableViewCell.m
//  BabyBluetoothAppDemo
//
//  Created by mqw on 2020/5/31.
//  Copyright © 2020 刘彦玮. All rights reserved.
//

#import "DeviceTableViewCell.h"
#import "UIColor+IMSAdditions.h"

@interface DeviceTableViewCell ()
@property (weak, nonatomic) IBOutlet UIButton *editButton;

@end

@implementation DeviceTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
//    self.selectButton.hidden = NO;
//    self.leftContent.constant = 40;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated{//重写高亮函数
    if (highlighted) {
        self.contentView.backgroundColor = [UIColor ims_colorWithHexRGB:0x3f71bb];
    }else {
        self.contentView.backgroundColor = [UIColor whiteColor];
    }
}

- (IBAction)enterEditButton:(UIButton *)sender {
    if (self.editBlock) {
        self.editBlock();
    }
}
@end
