//
//  HexadecimalConversionTool.m
//  roller
//
//  Created by goblin on 2021/5/19.
//

#import "HexadecimalConversionTool.h"

@implementation HexadecimalConversionTool

#pragma mark 存储数据
+(void)saveDataByKeyNSUserDefaults:(NSString *)strKey andValue:(NSString *)strValue{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:strValue forKey:strKey];
    [userDefaults synchronize];
}
#pragma mark 读取数据
+(NSString *)readDataByKeyNSUserDefaults:(NSString *)strKey {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *strValue = [userDefaults stringForKey:strKey];
    if (strValue == nil) strValue = @"";
    return strValue;
}


#pragma mark 字符串转16进制data
+ (NSData *)dataWithHexString:(NSString *)hexString
{
    // hexString的长度应为偶数
    if ([hexString length] % 2 != 0)
        return nil;
    
    NSUInteger len = [hexString length];
    NSMutableData *retData = [[NSMutableData alloc] init];
    const char *ch = [[hexString dataUsingEncoding:NSASCIIStringEncoding] bytes];
    for (int i=0 ; i < len ; i+=2) {
        
        int height=0;
        if (ch[i]>='0' && ch[i]<='9')
            height = ch[i] - '0';
        else if (ch[i]>='A' && ch[i]<='F')
            height = ch[i] - 'A' + 10;
        else if (ch[i]>='a' && ch[i]<='f')
            height = ch[i] - 'a' + 10;
        else
            // 错误数据
            return nil;
        
        int low=0;
        if (ch[i+1]>='0' && ch[i+1]<='9')
            low = ch[i+1] - '0';
        else if (ch[i+1]>='A' && ch[i+1]<='F')
            low = ch[i+1] - 'A' + 10;
        else if (ch[i+1]>='a' && ch[i+1]<='f')
            low = ch[i+1] - 'a' + 10;
        else
            // 错误数据
            return nil;
        
        int byteValue = height*16 + low;
        [retData appendBytes:&byteValue length:1];
    }
    return retData;
}
#pragma mark 16进制data转16进制字符串
+ (NSString *)dataToHexString:(NSData *)data {
    NSMutableString *string = [[NSMutableString alloc] initWithCapacity:[data length]];
    [data enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange, BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i = 0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) & 0xff];
            if ([hexStr length] == 2) {
                [string appendString:hexStr];
            } else {
                [string appendFormat:@"0%@", hexStr];
            }
        }
    }];
    return string;
}
#pragma mark 16进制data转16进制字符数组
+ (NSArray *)dataToHexStringArray:(NSData *)data {
    NSMutableArray *results = [[NSMutableArray alloc] init];
    [data enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange, BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i = 0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) & 0xff];
            hexStr = [hexStr uppercaseString];
            if ([hexStr length] == 2) {
                [results addObject:hexStr];
            } else {
                [results addObject:[NSString stringWithFormat:@"0%@", hexStr]];
            }
        }
    }];
    return results;
}
#pragma mark 字符串包含英文(16进制)
+ (BOOL)isContainEnglish:(NSString *)string {
    //英文字条件
    NSRegularExpression *tLetterRegularExpression = [NSRegularExpression regularExpressionWithPattern:@"[A-Za-z]" options:NSRegularExpressionCaseInsensitive error:nil];
    //符合英文字条件的有几个字节
    NSUInteger tLetterMatchCount = [tLetterRegularExpression numberOfMatchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, string.length)];
    return !tLetterMatchCount;
}
#pragma mark 10进制转16进制
+ (NSString *)ToHex:(NSString *)string
{
    if (![HexadecimalConversionTool isContainEnglish:string]) {
        return string;
    }
    long long int tmpid = [string integerValue];
    NSString *nLetterValue;
    NSString *str = @"";
    long long int ttmpig;
    for (int i = 0; i<9; i++) {
        ttmpig=tmpid%16;
        tmpid=tmpid/16;
        switch (ttmpig)
        {
            case 10:
                nLetterValue =@"A";break;
            case 11:
                nLetterValue =@"B";break;
            case 12:
                nLetterValue =@"C";break;
            case 13:
                nLetterValue =@"D";break;
            case 14:
                nLetterValue =@"E";break;
            case 15:
                nLetterValue =@"F";break;
            default:nLetterValue=[[NSString alloc]initWithFormat:@"%lli",ttmpig];
                
        }
        str = [nLetterValue stringByAppendingString:str];
        if (tmpid == 0) {
            break;
        }
        
    }
    if (str.length % 2 != 0) {
        str = [NSString stringWithFormat:@"0%@", str];
    }
    return str;
}
#pragma mark 二进制转十进制
+ (NSString *)convertDecimalSystemFromBinarySystem:(NSString *)binary
{
    NSInteger ll = 0 ;
    NSInteger  temp = 0 ;
    for (NSInteger i = 0; i < binary.length; i ++){
        
        temp = [[binary substringWithRange:NSMakeRange(i, 1)] intValue];
        temp = temp * powf(2, binary.length - i - 1);
        ll += temp;
    }
    
    NSString * result = [NSString stringWithFormat:@"%ld",(long)ll];
    
    return result;
}
#pragma mark 16进制转2进制数组
+ (NSArray *)hexadecimalToBinaryArray:(NSString *)string {
    NSString *hex = [HexadecimalConversionTool hexadecimalToBinary:string];
    NSArray *results = [HexadecimalConversionTool binaryToArray:hex];
    return results;
}
#pragma mark 16进制转2进制
+ (NSString *)hexadecimalToBinary:(NSString *)string {
    NSMutableDictionary *hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
        [hexDic setObject:@"0000" forKey:@"0"];
        [hexDic setObject:@"0001" forKey:@"1"];
        [hexDic setObject:@"0010" forKey:@"2"];
        [hexDic setObject:@"0011" forKey:@"3"];
        [hexDic setObject:@"0100" forKey:@"4"];
        [hexDic setObject:@"0101" forKey:@"5"];
        [hexDic setObject:@"0110" forKey:@"6"];
        [hexDic setObject:@"0111" forKey:@"7"];
        [hexDic setObject:@"1000" forKey:@"8"];
        [hexDic setObject:@"1001" forKey:@"9"];
        [hexDic setObject:@"1010" forKey:@"A"];
        [hexDic setObject:@"1011" forKey:@"B"];
        [hexDic setObject:@"1100" forKey:@"C"];
        [hexDic setObject:@"1101" forKey:@"D"];
        [hexDic setObject:@"1110" forKey:@"E"];
        [hexDic setObject:@"1111" forKey:@"F"];
        
        NSString *binary = @"";
        for (int i=0; i<[string length]; i++) {
            
            NSString *key = [string substringWithRange:NSMakeRange(i, 1)];
            NSString *value = [hexDic objectForKey:key.uppercaseString];
            if (value) {
                binary = [binary stringByAppendingString:value];
            }
        }
        return binary;
}
#pragma mark 二进制字符串转数组
+ (NSArray *)binaryToArray:(NSString *)string {
    NSMutableArray *results = [[NSMutableArray alloc] init];
    for (int i = 0; i < string.length; i++) {
        NSString *str = [string substringWithRange:NSMakeRange(i, 1)];
        [results addObject:str];
    }
    return [results copy];
}

+ (NSString *)binaryStringToString:(NSString *)binaryString {
    if ([binaryString isEqualToString:@"10"]) {
        return @"02";
    }
    return binaryString;
}
@end
