//
//  ReceiveSendViewController.h
//  HLKRadarTool
//
//  Created by hilink on 2024/11/7.
//  Copyright © 2024 刘彦玮. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ReceiveSendViewController : BaseViewController

@property (nonatomic,strong)CBCharacteristic *characteristicRead;
@property (nonatomic,strong)CBCharacteristic *characteristicWrite;
@property (nonatomic, strong) ZZW_Device *currentDevice;

@end

NS_ASSUME_NONNULL_END
