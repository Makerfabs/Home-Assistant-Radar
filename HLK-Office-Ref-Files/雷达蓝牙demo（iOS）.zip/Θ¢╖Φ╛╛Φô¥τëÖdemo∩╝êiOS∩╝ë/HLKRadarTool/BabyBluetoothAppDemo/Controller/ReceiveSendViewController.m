//
//  ReceiveSendViewController.m
//  HLKRadarTool
//
//  Created by hilink on 2024/11/7.
//  Copyright © 2024 刘彦玮. All rights reserved.
//

#import "ReceiveSendViewController.h"

@interface ReceiveSendViewController ()

@property (nonatomic, strong)UITextView *textView;

@property (nonatomic, strong) NSString *logs;

@end

@implementation ReceiveSendViewController

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOnRecvPipeDataALL object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOnDisconnectPeripheral object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BabyNotificationAtDidDisconnectPeripheral object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设备详情";
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UITextView *textView = [[UITextView alloc] init];
    textView.frame = CGRectMake(30, 130, self.view.bounds.size.width - 60, self.view.bounds.size.height - 230);
    textView.layer.cornerRadius = 10;
    textView.clipsToBounds = YES;
    textView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    textView.layer.borderWidth = 1;
    textView.font = [UIFont systemFontOfSize:13];
    textView.textColor = [UIColor blackColor];
    [self.view addSubview:textView];
    self.textView = textView;
}

- (void)viewWillAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onRecvPipeDataAll:) name:kOnRecvPipeDataALL object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doDisConnectWork) name:kOnDisconnectPeripheral object:nil];
    //蓝牙监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doDisConnectWork) name:BabyNotificationAtDidDisconnectPeripheral object:nil];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOnRecvPipeDataALL object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOnDisconnectPeripheral object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BabyNotificationAtDidDisconnectPeripheral object:nil];
}

//接收数据
- (void)onRecvPipeDataAll:(NSNotification*)notify {
    NSDictionary*recvDic = notify.userInfo;
    NSString*deviceID = [recvDic objectForKey:@"deviceID"];
    
    NSString *obj_data = [recvDic objectForKey:@"OBJ_DATA"];
    if (self.logs.length > 0) {
        self.logs = [obj_data stringByAppendingString:[NSString stringWithFormat:@"\n%@",self.logs]];
    }else {
        self.logs = obj_data;
    }
    self.textView.text = self.logs;
}

//写数据到设备
- (void)wirteData {
    //示例
//    NSData*cmd = [[DeviceInfo sharedClient]sendCMDToDevice:@"a900" withCmdData:[DeviceInfo convertDataToHexStr:data]];
//    [self.currentDevice.bleDevice writeValue:cmd forCharacteristic:self.characteristicWrite type:CBCharacteristicWriteWithoutResponse];
}

-(void)doDisConnectWork{
    [self showAlertErr:NSLocalizedString(@"lanya_duankai_tuihui_liebiao", @"蓝牙连接已断开，即将退回列表页面")];
}

-(void)showAlertErr:(NSString*)errmsg{
    WS(weakSelf);
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:errmsg preferredStyle:UIAlertControllerStyleAlert];
             UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"que_ding", @"确定") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
                 [weakSelf.navigationController popToRootViewControllerAnimated:YES];
             }];
    [alertController addAction:confirmAction];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

@end
