//
//  BaseViewController.h
//  HLKRadarTool
//
//  Created by 佐文周 on 2022/9/21.
//  Copyright © 2022 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN






@interface BaseViewController : UIViewController

- (void)backAction;

@end

NS_ASSUME_NONNULL_END
