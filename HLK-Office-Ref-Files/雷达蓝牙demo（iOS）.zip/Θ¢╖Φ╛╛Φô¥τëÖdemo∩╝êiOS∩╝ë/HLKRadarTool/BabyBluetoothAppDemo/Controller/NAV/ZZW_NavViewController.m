//
//  ZZW_NavViewController.m
//  Kaisi_TimingDevice
//
//  Created by mqw on 2021/9/18.
//

#import "ZZW_NavViewController.h"

@interface ZZW_NavViewController ()

@end

@implementation ZZW_NavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (@available(iOS 15.0, *)) {
        UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
        appearance.backgroundImage = [UIImage imageNamed:@"nav_bg"]; //图片
        appearance.backgroundColor = UIColor.clearColor; //背景色
        appearance.shadowColor = UIColor.clearColor; //阴影
        UIFont *font = [UIFont fontWithName:@"PingFang-SC-Medium" size: 18];
        appearance.titleTextAttributes = @{NSFontAttributeName:font,NSForegroundColorAttributeName:[UIColor whiteColor]};
        //等等其它属性，可以参考其他文章。
        self.navigationBar.standardAppearance = appearance;
        self.navigationBar.scrollEdgeAppearance = appearance;
    }else {
        UIFont *font = [UIFont fontWithName:@"PingFang-SC-Medium" size: 18];
        [self.navigationBar setTitleTextAttributes:@{NSFontAttributeName:font,NSForegroundColorAttributeName:[UIColor whiteColor]}];
        
        self.navigationBar.backgroundColor = [UIColor clearColor];
        
        UIImage *backGroundImage = [UIImage imageNamed:@"nav_bg"];
        backGroundImage = [backGroundImage resizableImageWithCapInsets:UIEdgeInsetsZero resizingMode:UIImageResizingModeStretch];
        [self.navigationBar setBackgroundImage:backGroundImage forBarMetrics:UIBarMetricsDefault];
    }
    //自定义返回按钮  (全局设置)
    [[UIBarButtonItem appearance] setTintColor:[UIColor whiteColor]];
}

//重写push后返回按钮的文字,文字可以为空字符串.
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [super pushViewController:viewController animated:animated];
    
    //修改返回文字
    UIButton *backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    [backButton setTitle:@"" forState:UIControlStateNormal];
    [backButton setImage:[UIImage imageNamed:@"back_white"] forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backButton];
//    viewController.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"fan_hui", @"返回") style:UIBarButtonItemStyleDone target:nil action:nil];
}

- (void)backAction {
    [self popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

@end
