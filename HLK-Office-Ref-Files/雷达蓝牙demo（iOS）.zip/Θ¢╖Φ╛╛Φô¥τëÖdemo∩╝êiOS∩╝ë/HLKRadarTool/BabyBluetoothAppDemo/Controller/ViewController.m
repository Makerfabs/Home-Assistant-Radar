//
//  ViewController.m
//  BabyBluetoothAppDemo
//
//  Created by 刘彦玮 on 15/8/1.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import "ViewController.h"
#import "SVProgressHUD.h"
#import "UIViewController+HUD.h"
#import "AppDelegate.h"
#import "DeviceTableViewCell.h"
#import "PwdAlertView.h"
#import "DeviceInfo.h"
#import "ZZW_Device.h"
#import "ReceiveSendViewController.h"

#define ColorWithRGB(r,g,b) [UIColor colorWithRed:r/255. green:g/255. blue:b/255. alpha:1]

#define PRE_FIX  @"HLK-LD"

@interface ViewController () {
    BabyBluetooth *baby;

    Boolean isGoToContr;
    CBCharacteristic *characteristicRead;
    CBCharacteristic *characteristicWrite;
    
    CBCharacteristic *OTA_2450_characteristicRead;
    CBCharacteristic *OTA_2450_characteristicWrite;
}
@property (nonatomic, strong) NSMutableArray *peripheralDataArray;
@property (nonatomic, strong) UIAlertController *myAlertVC;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *myActivity;
@property (nonatomic, assign) NSInteger currentIndex;/**< 当前设备下标 */
@property (weak, nonatomic) IBOutlet UILabel *searchTitleLabel;/**< 搜索标题 */
@property (nonatomic, strong) NSString *currentPassword;/**< 当前设备控制密码 */

@property (nonatomic, assign) int isBLE_state_on;/**< 当前蓝牙的状态 */


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = NSLocalizedString(@"shebei_liebiao", @"设备列表");
    self.searchTitleLabel.text = NSLocalizedString(@"leida_shebei_sousuo_zhong", @"雷达设备搜索中...");
    [SVProgressHUD showInfoWithStatus:NSLocalizedString(@"zhunbeu_dakai_shebei", @"准备打开设备")];
    NSLog(@"viewDidLoad");
    self.peripheralDataArray = [[NSMutableArray alloc]init];

    //初始化BabyBluetooth 蓝牙库
    baby = [BabyBluetooth shareBabyBluetooth];

    [_tableView registerNib:[UINib nibWithNibName:@"DeviceTableViewCell" bundle:nil] forCellReuseIdentifier:@"DeviceTableViewCell"];

    [self.myActivity startAnimating];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doDisConnectWork) name:kOnDisconnectPeripheral object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doBLE_state_off) name:@"CBPeripheralManagerStatePoweredOff" object:nil];
}

-(void)doBLE_state_off{
    self.isBLE_state_on = -1;
    [self ble_state_update];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

    NSLog(@"viewDidAppear");
    [self.peripheralDataArray removeAllObjects];
    [self.tableView reloadData];
    //停止之前的连接
    [baby cancelAllPeripheralsConnection];
    //设置委托后直接可以使用，无需等待CBCentralManagerStatePoweredOn状态。
    baby.scanForPeripherals().begin();
    //baby.scanForPeripherals().begin().stop(10);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onRecvPipeData:) name:kOnRecvPipeData object:nil];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"viewWillDisappear");
    characteristicRead = nil;
    characteristicWrite = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOnRecvPipeData object:nil];
}

-(void)viewWillAppear:(BOOL)animated{
    [self babyDelegate];
}
#pragma mark -蓝牙配置和操作
-(void)ble_state_update{
    if(self.isBLE_state_on == 1){
        [SVProgressHUD showInfoWithStatus:NSLocalizedString(@"shebei_dakai_chenggong", @"设备打开成功，开始扫描设备")];
        self.searchTitleLabel.textColor = [UIColor ims_colorWithRed:5 green:125 blue:255];
        self.searchTitleLabel.text = NSLocalizedString(@"leida_shebei_sousuo_zhong", @"雷达设备搜索中...");
        [self.myActivity startAnimating];
        
        [baby cancelAllPeripheralsConnection];
        //设置委托后直接可以使用，无需等待CBCentralManagerStatePoweredOn状态。
        baby.scanForPeripherals().begin();
        
        [self.myAlertVC dismissViewControllerAnimated:YES completion:^{
            self.myAlertVC = nil;
        }];
    }else   if(self.isBLE_state_on ==-1){
        [self.peripheralDataArray removeAllObjects];
        [self.tableView reloadData];
        [baby cancelScan];
        self.searchTitleLabel.textColor = [UIColor redColor];
        
        [self.myActivity stopAnimating];
        self.searchTitleLabel.text = NSLocalizedString(@"dakai_lanya_gongneng", @"请打开蓝牙功能，否则将无法使用");

        [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"dakai_lanya_gongneng", @"请打开蓝牙功能，否则将无法使用")];
    }
}
//蓝牙网关初始化和委托方法设置
-(void)babyDelegate{
    __weak typeof(self) weakSelf = self;
    [baby setBlockOnCentralManagerDidUpdateState:^(CBCentralManager *central) {
        weakSelf.isBLE_state_on = central.state == CBCentralManagerStatePoweredOn?1:-1;
        [weakSelf ble_state_update];
    }];
    
    //设置扫描到设备的委
    [baby setBlockOnDiscoverToPeripherals:^(CBCentralManager *central, CBPeripheral *peripheral, NSDictionary *advertisementData, NSNumber *RSSI) {
        int myInt = [RSSI intValue];
        NSLog(@"搜索到了设备:%@-----RSSI:[%d]",peripheral.name,myInt);
        [weakSelf insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
        
    }];

   //设置发现设service的Characteristics的委托
   [baby setBlockOnDiscoverCharacteristicsAtChannel:@"124" block:^(CBPeripheral *peripheral, CBService *service, NSError *error) {
       NSLog(@"mqw__===service name:%@",service.UUID);
       NSString*uudi = service.UUID.UUIDString;
       if ([peripheral.name hasPrefix:@"HLK-LD2450"]) {//2450
           NSLog(@"mqw__===service uuid:%@",uudi);
           if([uudi isEqual:@"AE00"]){
               //FIXME 升级特征
               for (int row=0;row<service.characteristics.count;row++) {
                   CBCharacteristic *c = service.characteristics[row];
                   NSString* characteristicUuid = [NSString stringWithFormat:@"%@",c.UUID];
                   if ([characteristicUuid isEqual:@"AE02"]) {
                       OTA_2450_characteristicRead = c;
                   }else if ([characteristicUuid isEqual:@"AE01"]) {
                       OTA_2450_characteristicWrite = c;
                   }
               }
           }else if([uudi isEqual:@"FFF0"]){
               //配置参数读写特征
               for (int row=0;row<service.characteristics.count;row++) {
                   CBCharacteristic *c = service.characteristics[row];
                   NSString* characteristicUuid = [NSString stringWithFormat:@"%@",c.UUID];
                   if ([characteristicUuid isEqual:@"FFF1"]  || [characteristicUuid isEqualToString:@"0000FFF1-0000-1000-8000-00805F9B34FB"]) {
                       characteristicRead = c;

                   }else if ([characteristicUuid isEqual:@"FFF2"] || [characteristicUuid isEqualToString:@"0000FFF2-0000-1000-8000-00805F9B34FB"]) {
                       characteristicWrite = c;
                   }
               }
           }
           if(characteristicRead!=nil  || OTA_2450_characteristicRead!=nil){
               ZZW_Device *item = weakSelf.peripheralDataArray[weakSelf.currentIndex];
               //开启接收广播通知
               weakSelf.currPeripheral = peripheral;
               [self doCharacteristicReadNotifyOpen];
               [weakSelf goToControVCWithDic:item];
           }
       } else {
          if([uudi isEqual:@"FFF0"]  || [uudi isEqualToString:@"0000FFF0-0000-1000-8000-00805F9B34FB"])
           {
               for (int row=0;row<service.characteristics.count;row++) {
                   CBCharacteristic *c = service.characteristics[row];
                   NSString* characteristicUuid = [NSString stringWithFormat:@"%@",c.UUID];
                   if ([characteristicUuid isEqual:@"FFF1"]  || [characteristicUuid isEqualToString:@"0000FFF1-0000-1000-8000-00805F9B34FB"]) {
                       characteristicRead = c;
                       
                   }else if ([characteristicUuid isEqual:@"FFF2"] || [characteristicUuid isEqualToString:@"0000FFF2-0000-1000-8000-00805F9B34FB"]) {
                       characteristicWrite = c;
                   }
               }
               //开启接收广播通知
               weakSelf.currPeripheral = peripheral;
               [self doCharacteristicReadNotifyOpen];
               
               ZZW_Device *item = weakSelf.peripheralDataArray[weakSelf.currentIndex];
               if ([item.keyName containsString:@"HLK-LD2412"] || [item.keyName containsString:@"HLK-LD2411-S"] || [item.keyName containsString:@"HLK-LD2451"] ||[item.keyName containsString:@"HLK-6002"]) {
                   //跳转至控制页面
                   ZZW_Device *item = weakSelf.peripheralDataArray[weakSelf.currentIndex];
                   [weakSelf goToControVCWithDic:item];
               }
               else {
                   if (item.deviceType == Haved_Ver_Haved_CheckPwd_Haved_Upgrade_Haved_SPI) {
                       [weakSelf ims_hideHUD];
                       if (item.otaStatus) {
                           [weakSelf goToControVCWithDic:item];
                       } else {
                           NSString *macAddress = item.macAddress;
                           
                           if (![[NSUserDefaults standardUserDefaults] objectForKey:macAddress]) {
                               weakSelf.currentPassword = @"HiLink";
                               NSData *data = [[[NSUserDefaults standardUserDefaults] objectForKey:macAddress] dataUsingEncoding:NSASCIIStringEncoding];
                               NSData*cmd = [[DeviceInfo sharedClient]sendCMDToDevice:@"A800" withCmdData:[DeviceInfo convertDataToHexStr:data]];
                               [weakSelf.currPeripheral writeValue:cmd forCharacteristic:characteristicWrite type:CBCharacteristicWriteWithoutResponse];
                           } else {
                               weakSelf.currentPassword = [[NSUserDefaults standardUserDefaults] objectForKey:macAddress];
                               NSData *data = [[[NSUserDefaults standardUserDefaults] objectForKey:macAddress] dataUsingEncoding:NSASCIIStringEncoding];
                               NSData*cmd = [[DeviceInfo sharedClient]sendCMDToDevice:@"A800" withCmdData:[DeviceInfo convertDataToHexStr:data]];
                               [weakSelf.currPeripheral writeValue:cmd forCharacteristic:characteristicWrite type:CBCharacteristicWriteWithoutResponse];
                           }
                       }
                   }else {
                       //跳转至控制页面
                       ZZW_Device *item = weakSelf.peripheralDataArray[weakSelf.currentIndex];
                       [weakSelf goToControVCWithDic:item];
                   }
               }
           }
       }
   }];

    //设置读取characteristics的委托
    [baby setBlockOnReadValueForCharacteristic:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
        NSLog(@"characteristic name:%@ value is:%@",characteristics.UUID,characteristics.value);
    }];
    //设置发现characteristics的descriptors的委托
    [baby setBlockOnDiscoverDescriptorsForCharacteristic:^(CBPeripheral *peripheral, CBCharacteristic *characteristic, NSError *error) {
        NSLog(@"===characteristic name:%@",characteristic.service.UUID);
        for (CBDescriptor *d in characteristic.descriptors) {
            NSLog(@"CBDescriptor name is :%@",d.UUID);
        }
    }];
    //设置读取Descriptor的委托
    [baby setBlockOnReadValueForDescriptors:^(CBPeripheral *peripheral, CBDescriptor *descriptor, NSError *error) {
        NSLog(@"Descriptor name:%@ value is:%@",descriptor.characteristic.UUID, descriptor.value);
    }];

    //设置查找设备的过滤器
    [baby setFilterOnDiscoverPeripherals:^BOOL(NSString *peripheralName, NSDictionary *advertisementData, NSNumber *RSSI) {
        if ([peripheralName hasPrefix:PRE_FIX]) {
            return YES;
        }
        return NO;
    }];

    [baby setBlockOnCancelAllPeripheralsConnectionBlock:^(CBCentralManager *centralManager) {
        NSLog(@"setBlockOnCancelAllPeripheralsConnectionBlock");
    }];
   
    [baby setBlockOnCancelScanBlock:^(CBCentralManager *centralManager) {
        NSLog(@"setBlockOnCancelScanBlock");
    }];

    //连接失败
    [baby setBlockOnFailToConnect:^(CBCentralManager *central, CBPeripheral *peripheral, NSError *error) {
        [weakSelf ims_showHUDWithMessage:NSLocalizedString(@"lianjie_shibai_zaishi_yichi", @"连接失败，请将手机和设备尽量靠近，再试一次！")];
    }];

    //示例:
    //扫描选项->CBCentralManagerScanOptionAllowDuplicatesKey:忽略同一个Peripheral端的多个发现事件被聚合成一个发现事件
    NSDictionary *scanForPeripheralsWithOptions = @{CBCentralManagerScanOptionAllowDuplicatesKey:@YES};
    //连接设备->
    [baby setBabyOptionsWithScanForPeripheralsWithOptions:scanForPeripheralsWithOptions connectPeripheralWithOptions:nil scanForPeripheralsWithServices:nil discoverWithServices:nil discoverWithCharacteristics:nil];
}

//跳转至控制页面
- (void)goToControVCWithDic:(ZZW_Device *)model {
    if(isGoToContr) {
        isGoToContr = NO;
        [self ims_hideHUD];
    }
    ReceiveSendViewController *vc = [[ReceiveSendViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -UIViewController 方法
//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    NSArray *peripherals = [_peripheralDataArray valueForKeyPath:@"bleDevice"];
    if(![peripherals containsObject:peripheral]) {
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:peripherals.count inSection:0];
        [indexPaths addObject:indexPath];
        
        ZZW_Device *model = [ZZW_Device new];
        model.bleDevice = peripheral;
        model.bleDic = advertisementData;
        model.RSSI = RSSI;
        model.keyName = peripheral.name;
        //判断是否有广播  是否需要验证密码
        if ([model.bleDic objectForKey:@"kCBAdvDataManufacturerData"]) {
            NSData *data = [advertisementData objectForKey:@"kCBAdvDataManufacturerData"];
            if (data.length == 8) {
                NSString *dataStr = [DeviceInfo convertDataToHexStr:data];
                
                NSString *verStr = [NSString stringWithFormat:@"%d.%@.%@%@%@%@",[[dataStr substringWithRange:NSMakeRange(6,2)] intValue],[dataStr substringWithRange:NSMakeRange(4,2)],[dataStr substringWithRange:NSMakeRange(dataStr.length-4,2)],[dataStr substringWithRange:NSMakeRange(dataStr.length-2,2)],[dataStr substringWithRange:NSMakeRange(dataStr.length-8,2)],[dataStr substringWithRange:NSMakeRange(dataStr.length-6,2)]];
                model.currentVersion = verStr;
                model.deviceType = Haved_Ver_No_CheckPwd_No_Upgrade_Haved_SPI;
            } else {
                if (data.length >= 15) {
                    NSString *dataStr = [DeviceInfo convertDataToHexStr:data];
                    NSString *verStr = [NSString stringWithFormat:@"%d.%@.%@%@%@%@",[[dataStr substringWithRange:NSMakeRange(6,2)] intValue],[dataStr substringWithRange:NSMakeRange(4,2)],[dataStr substringWithRange:NSMakeRange(14,2)],[dataStr substringWithRange:NSMakeRange(12,2)],[dataStr substringWithRange:NSMakeRange(10,2)],[dataStr substringWithRange:NSMakeRange(8,2)]];
                    model.currentVersion = verStr;
                    
                    int otaStatus = [[dataStr substringWithRange:NSMakeRange(16, 2)] intValue];
                    model.otaStatus = otaStatus;
                    //2410因资源不够才需要判断是否升级中，其他模组无须判断
                    if([model.keyName containsString:@"HLK-LD2412"] || [model.keyName containsString:@"HLK-LD2451"] ){
                        model.otaStatus = NO;
                    }
                    NSString *macAddress = [[DeviceInfo convertDataToHexStr:data] substringWithRange:NSMakeRange(18, 12)];
                    model.macAddress = macAddress;
                    if (![peripheral.name containsString:@"HLK-LD2411"]) {
                        model.deviceType = Haved_Ver_Haved_CheckPwd_Haved_Upgrade_Haved_SPI;
                    }
                }
            }
        }else {
            //老版本
            model.deviceType = No_Receive_Old;
        }
        [_peripheralDataArray addObject:model];
        
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }else{
        //存在了，更新信息
        [self updateDeviceinf:peripheral RSSI:RSSI];
    }
}

-(void)updateDeviceinf: (CBPeripheral *)peripheral  RSSI:(NSNumber *)RSSI {
    if([RSSI intValue]==127)
        return;
    [self.tableView reloadData];
}

#pragma mark -table委托 table delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
     return _peripheralDataArray.count;
}

- (CGFloat)tableView:(nonnull UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString*cellIdentifier = @"DeviceTableViewCell";
    DeviceTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    ZZW_Device *item = [_peripheralDataArray objectAtIndex:indexPath.row];
    CBPeripheral *peripheral = item.bleDevice;
    NSDictionary *advertisementData = item.bleDic;
    if (!cell) {
        cell = [[DeviceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault  reuseIdentifier: cellIdentifier];
    }
    NSString *peripheralName;
    if ([advertisementData objectForKey:@"kCBAdvDataLocalName"]) {
        peripheralName = [NSString stringWithFormat:@"%@",[advertisementData objectForKey:@"kCBAdvDataLocalName"]];
    }else if(!([peripheral.name isEqualToString:@""] || peripheral.name == nil)){
        peripheralName = peripheral.name;
    }else{
        peripheralName = [peripheral.identifier UUIDString];
    }
    cell.deviceName.text = item.keyName;
    if (item.currentVersion) {
        if (item.otaStatus) {
            cell.versionLabel.text = [NSString stringWithFormat:@"V %@%@",item.currentVersion,NSLocalizedString(@"dengdai_shengji", @"(等待升级)")];
        } else {
            cell.versionLabel.text = [NSString stringWithFormat:@"V %@",item.currentVersion];
        }
    } else {
        cell.versionLabel.text = @"--";
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    //信号和服务
    cell.connectState.text = [NSString stringWithFormat:@"RSSI:%@",item.RSSI];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //停止扫描
    [baby cancelScan];

     ZZW_Device *item = [_peripheralDataArray objectAtIndex:indexPath.row];

    isGoToContr = YES;
    [self ims_showHUDIndicatorWithMessage:NSLocalizedString(@"qing_shaohou", @"请稍后...")];
    self.currentIndex = indexPath.row;
    baby.having(item.bleDevice).and.channel(@"124").then.connectToPeripherals().discoverServices().discoverCharacteristics().discoverDescriptorsForCharacteristic().begin();

}


-(void)doCharacteristicReadNotifyOpen
{
    if (!characteristicRead) {
        characteristicRead = OTA_2450_characteristicRead;
    }
[self.currPeripheral setNotifyValue:YES forCharacteristic:characteristicRead];
[baby notify:self.currPeripheral
  characteristic:characteristicRead
           block:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
         
    NSData* recv =     characteristics.value;
    if (recv == nil ) {
        return ;
    }
    NSString*cmd = [DeviceInfo convertDataToHexStr:recv];
    [[DeviceInfo sharedClient]parseLocalDataWithDeviceID:cmd withDevice:peripheral.name];
}];

}

- (void)onRecvPipeData:(NSNotification*)notify{
WS(weakSelf);
int OperationType = [[notify.userInfo objectForKey:@"OperationType"]intValue];
if (OperationType == CMD_SEND_BACK_RECV) {
    NSDictionary*tempDic = [notify.userInfo objectForKey:@"CMD_DATA"];
    //读写返回
    int cmdType =  [[notify.userInfo objectForKey:@"CMD_DATA_TYPE"]intValue];
    if (cmdType == 0xa801) {//校验密码
        Boolean isOK = [[tempDic objectForKey:@"isOK"] boolValue];
        if (isOK) {
            ZZW_Device *dic = self.peripheralDataArray[self.currentIndex];
            if (dic.macAddress) {
                [[NSUserDefaults standardUserDefaults] setValue:self.currentPassword forKey:dic.macAddress];
            }
            
            //密码校验通过
            PwdAlertView *alertView = [PwdAlertView sharePWDAlertView];
            [alertView removeFromSuperview];
            
            ZZW_Device *item = self.peripheralDataArray[self.currentIndex];
            item.password = self.currentPassword;
            [self.peripheralDataArray replaceObjectAtIndex:self.currentIndex withObject:item];
            
            [self goToControVCWithDic:item];
        }else {
            PwdAlertView *alertView = [PwdAlertView sharePWDAlertView];
            [alertView removeFromSuperview];
//                   alertView.defaulPassword = @"";
            alertView.currentPassword = @"";
            alertView.cancelBlock = ^{
                [alertView removeFromSuperview];
                [baby cancelAllPeripheralsConnection];
            };
            
            alertView.pwdBlock = ^(NSString * _Nonnull pwdStr) {
                //48 69 4c 69 6e 6b
                NSData *data = [pwdStr dataUsingEncoding:NSASCIIStringEncoding];
                NSData*cmd = [[DeviceInfo sharedClient]sendCMDToDevice:@"a800" withCmdData:[DeviceInfo convertDataToHexStr:data]];
                [weakSelf.currPeripheral writeValue:cmd forCharacteristic:characteristicWrite type:CBCharacteristicWriteWithoutResponse];
            };
            
            [[kAppDelegate window] addSubview:alertView];
            alertView.errorLabel.hidden = NO;
        }
    }
}
}

-(void)doDisConnectWork{
    NSLog(@"蓝牙连接已断开，即将退回列表页面");
    [self ims_hideHUD];
}
@end
