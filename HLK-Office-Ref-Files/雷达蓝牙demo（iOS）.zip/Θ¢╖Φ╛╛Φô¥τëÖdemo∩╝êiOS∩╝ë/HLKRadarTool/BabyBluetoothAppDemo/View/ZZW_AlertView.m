//
//  ZZW_AlertView.m
//  HLKRadarTool
//
//  Created by 佐文周 on 2023/2/6.
//  Copyright © 2023 刘彦玮. All rights reserved.
//

#import "ZZW_AlertView.h"

@implementation ZZW_AlertView

//系统提示
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title andMessage:(NSString *)message {
    if ([super initWithFrame:frame]) {
        [self setUIWithTitle:title andMessage:message];
    }
    return self;
}

- (void)setUIWithTitle:(NSString *)title andMessage:(NSString *)message {
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    
    WS(weakSelf);
    //中间白框
    UIView *contentView = [UIView new];
    [self addSubview:contentView];
    contentView.backgroundColor = [UIColor whiteColor];
    contentView.layer.cornerRadius = 15;
    contentView.clipsToBounds = YES;
    [self addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.mas_equalTo(-30);
        make.leading.mas_equalTo(30);
        make.centerX.mas_equalTo(weakSelf);
        make.centerY.mas_equalTo(weakSelf);
        make.height.offset(220);
    }];
    
    //标题
    UILabel *titleLabel = [UILabel new];
    [contentView addSubview:titleLabel];
    titleLabel.text = title;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont systemFontOfSize:16];
    titleLabel.textColor = [UIColor blackColor];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.mas_equalTo(0);
        make.height.offset(20);
        make.top.mas_equalTo(10);
    }];
    
    //横线
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor ims_colorWithHexRGB:0xb2b2b2];
    [contentView addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.leading.mas_equalTo(0);
        make.height.offset(0.5);
        make.bottom.mas_equalTo(-51);
    }];
    
    UILabel *waringLabel = [UILabel new];
    waringLabel.numberOfLines = 0;
    waringLabel.textColor = [UIColor redColor];
    waringLabel.font = [UIFont systemFontOfSize:11];
    waringLabel.text = NSLocalizedString(@"提醒：尝鲜版本属于新增功能的体验版，可能会出现参数异常等情况,请谨慎使用。", @"提醒：尝鲜版本属于新增功能的体验版，可能会出现参数异常等情况,请谨慎使用。");
    [contentView addSubview:waringLabel];
    [waringLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(20);
        make.trailing.mas_equalTo(-20);
        make.bottom.mas_equalTo(line.mas_top);
        make.height.mas_equalTo(45);
    }];
    
    //提示文字
    UILabel *contentLabel = [UILabel new];
    contentLabel.numberOfLines = 0;
    contentLabel.textColor = [UIColor blackColor];
    contentLabel.font = [UIFont systemFontOfSize:15];
    [contentView addSubview:contentLabel];
    [contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(20);
        make.trailing.mas_equalTo(-20);
        make.bottom.mas_equalTo(waringLabel.mas_top);
        make.top.mas_equalTo(titleLabel.mas_bottom);
    }];
    contentLabel.text = message;
    
    //竖线
    UILabel *line2 = [UILabel new];
    line2.backgroundColor = [UIColor ims_colorWithHexRGB:0xb2b2b2];
    [contentView addSubview:line2];
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(0.5);
        make.height.offset(50.5);
        make.bottom.mas_equalTo(0);
        make.centerX.mas_equalTo(contentView);
    }];
    
    //确认按钮
    UIButton *confirmButton = [UIButton new];
    [confirmButton setTitle:NSLocalizedString(@"升级",@"升级") forState:UIControlStateNormal];
    [confirmButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [confirmButton addTarget:self action:@selector(enterConfirmButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:confirmButton];
    [confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.mas_equalTo(0);
        make.leading.mas_equalTo(line2.mas_trailing);
        make.bottom.mas_equalTo(contentView);
        make.top.mas_equalTo(line.mas_bottom);
    }];
    
    //取消按钮
    UIButton *cancelButton = [UIButton new];
    [cancelButton setTitle:NSLocalizedString(@"qu_xiao",@"取消") forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(enterCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:cancelButton];
    [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(0);
        make.trailing.mas_equalTo(line2.mas_leading);
        make.bottom.mas_equalTo(contentView);
        make.top.mas_equalTo(line.mas_bottom);
    }];
}

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title message:(NSString *)message confirmButtonTitle:(NSString *)confirmButtonTitle cancelButtonTitle:(NSString *)cancelButtonTitle {
    if ([super initWithFrame:frame]) {
        [self setUIWithTitle:title andMessage:message confirmButtonTitle:confirmButtonTitle cancelButtonTitle:cancelButtonTitle];
    }
    return self;
}

- (void)setUIWithTitle:(NSString *)title andMessage:(NSString *)message confirmButtonTitle:(NSString *)confirmButtonTitle cancelButtonTitle:(NSString *)cancelButtonTitle{
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    
    float messageHeight = [ZZW_Tool getStringHeightWithText:message font:[UIFont systemFontOfSize:17] viewWidth:kScreenWidth-50*2];
    WS(weakSelf);
    //中间白框
    UIView *contentView = [UIView new];
    [self addSubview:contentView];
    contentView.backgroundColor = [UIColor whiteColor];
    contentView.layer.cornerRadius = 15;
    contentView.clipsToBounds = YES;
    [self addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.mas_equalTo(-30);
        make.leading.mas_equalTo(30);
        make.centerX.mas_equalTo(weakSelf);
        make.centerY.mas_equalTo(weakSelf);
        make.height.offset(150+messageHeight);
    }];
    
    //标题
    UILabel *titleLabel = [UILabel new];
    [contentView addSubview:titleLabel];
    titleLabel.text = title;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont systemFontOfSize:16];
    titleLabel.textColor = [UIColor blackColor];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.mas_equalTo(0);
        make.height.offset(20);
        make.top.mas_equalTo(10);
    }];
    
    //提示文字
    UILabel *contentLabel = [UILabel new];
    contentLabel.numberOfLines = 0;
    contentLabel.textColor = [UIColor blackColor];
    [contentView addSubview:contentLabel];
    contentLabel.textAlignment = NSTextAlignmentCenter;
    [contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(20);
        make.trailing.mas_equalTo(-20);
        make.top.mas_equalTo(titleLabel.mas_bottom);
        make.bottom.mas_equalTo(-51);
    }];
    contentLabel.text = message;
    
    
    //横线
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor ims_colorWithHexRGB:0xb2b2b2];
    [contentView addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.leading.mas_equalTo(0);
        make.height.offset(0.5);
        make.bottom.mas_equalTo(-51);
    }];
    
    //竖线
    UILabel *line2 = [UILabel new];
    line2.backgroundColor = [UIColor ims_colorWithHexRGB:0xb2b2b2];
    [contentView addSubview:line2];
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(0.5);
        make.height.offset(50.5);
        make.bottom.mas_equalTo(0);
        make.centerX.mas_equalTo(contentView);
    }];
    
    //确认按钮
    UIButton *confirmButton = [UIButton new];
    [confirmButton setTitle:confirmButtonTitle forState:UIControlStateNormal];
    [confirmButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [confirmButton addTarget:self action:@selector(enterConfirmButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:confirmButton];
    [confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.mas_equalTo(0);
        make.leading.mas_equalTo(line2.mas_trailing);
        make.bottom.mas_equalTo(contentView);
        make.top.mas_equalTo(line.mas_bottom);
    }];
    
    //取消按钮
    UIButton *cancelButton = [UIButton new];
    [cancelButton setTitle:cancelButtonTitle forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(enterCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:cancelButton];
    [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(0);
        make.trailing.mas_equalTo(line2.mas_leading);
        make.bottom.mas_equalTo(contentView);
        make.top.mas_equalTo(line.mas_bottom);
    }];
}


- (void)enterCancelButton {
    [self removeFromSuperview];
    if (self.cancelBlock) {
        self.cancelBlock();
    }
}

- (void)enterConfirmButton {
    if (self.angainBlock) {
        self.angainBlock();
        [self removeFromSuperview];
    }
}


@end
