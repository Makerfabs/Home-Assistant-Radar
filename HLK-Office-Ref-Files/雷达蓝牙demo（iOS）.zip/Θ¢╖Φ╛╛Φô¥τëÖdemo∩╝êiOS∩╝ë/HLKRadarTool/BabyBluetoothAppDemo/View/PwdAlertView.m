//
//  PwdAlertView.m
//  SmartPhotoFrame
//
//  Created by 佐文周 on 2022/6/8.
//

#import "PwdAlertView.h"

@interface PwdAlertView ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField *psdTextField;/**< 密码输入框 */
@property (nonatomic, strong) UILabel *desLabel;

@end

@implementation PwdAlertView

//单例模式
+ (instancetype)sharePWDAlertView {
    static PwdAlertView *share = nil;
    static dispatch_once_t oneToken;
    dispatch_once(&oneToken, ^{
        share = [[PwdAlertView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight) andDefaultPassword:@""];
    });
   return share;
}

- (instancetype)initWithFrame:(CGRect)frame andDefaultPassword:(NSString *)pwd {
    if ([super initWithFrame:frame]) {
        [self setUIWithPwd:pwd];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame andPassword:(NSString *)password {
    if ([super initWithFrame:frame]) {
        [self changePwdWithPWD:password];
    }
    return self;
}

//修改密码框
-(void)changePwdWithPWD:(NSString *)pwdStr {
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    
    WS(weakSelf);
    //白色底框
    UIView *contentView = [UIView new];
    contentView.backgroundColor = [UIColor whiteColor];
    contentView.layer.cornerRadius = 15;
    contentView.clipsToBounds = YES;
    [self addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(25);
        make.right.mas_equalTo(-25);
        make.height.mas_equalTo(180);
        make.centerY.mas_equalTo(weakSelf);
    }];
    
    //标题
    UILabel *titleLabel = [UILabel new];
    titleLabel.text = NSLocalizedString(@"修改密码", @"修改密码");
    titleLabel.font = [UIFont systemFontOfSize:17];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [contentView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.left.right.mas_equalTo(0);
        make.height.mas_equalTo(20);
    }];
    
    self.psdTextField = [UITextField new];
    self.psdTextField.layer.borderWidth = 1;
    self.psdTextField.layer.cornerRadius = 5;
    self.psdTextField.layer.borderColor = [UIColor ims_colorWithHexRGB:0x969696].CGColor;
    self.psdTextField.clipsToBounds = YES;
    self.psdTextField.textAlignment = NSTextAlignmentCenter;
    self.psdTextField.borderStyle = UITextBorderStyleNone;
//    self.psdTextField.keyboardAppearance = UIKeyboardAppearanceDark;
    self.psdTextField.placeholder = NSLocalizedString(@"请输入6位的控制密码", @"请输入6位的控制密码");
    self.psdTextField.delegate = self;
    [contentView addSubview:self.psdTextField];
    [self.psdTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(50);
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(10);
    }];
    
    //确认按钮
    UIButton *confirmButton = [UIButton new];
    [confirmButton setTitle:NSLocalizedString(@"确定", @"确定") forState:UIControlStateNormal];
    [confirmButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    confirmButton.backgroundColor = MAIN_COLOE;
    confirmButton.layer.cornerRadius = 5.5;
    confirmButton.clipsToBounds = YES;
    [confirmButton addTarget:self action:@selector(enterConfirmButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:confirmButton];
    [confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo((kScreenWidth-25*2-20*3)/2.0);
        make.bottom.mas_equalTo(-20);
        make.height.mas_equalTo(40);
    }];
    
    //取消按钮
    UIButton *cancelButton = [UIButton new];
    [cancelButton setTitle:NSLocalizedString(@"取消", @"取消") forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    cancelButton.backgroundColor = [UIColor ims_colorWithHexRGB:0xAEABAB];
    cancelButton.layer.cornerRadius = 5.5;
    cancelButton.clipsToBounds = YES;
    [cancelButton addTarget:self action:@selector(enterCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:cancelButton];
    [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.width.mas_equalTo((kScreenWidth-25*2-20*3)/2.0);
        make.bottom.mas_equalTo(-20);
        make.height.mas_equalTo(40);
    }];
}

- (void)setUIWithPwd:(NSString *)pwdStr {
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    
    float desHeight = [ZZW_Tool getStringHeightWithText:NSLocalizedString(@"moren_mima", @"默认密码：HiLink(区分大小写)") font:[UIFont systemFontOfSize:18] viewWidth:kScreenWidth-60];
    
    WS(weakSelf);
    //白色底框
    UIView *contentView = [UIView new];
    contentView.backgroundColor = [UIColor whiteColor];
    contentView.layer.cornerRadius = 15;
    contentView.clipsToBounds = YES;
    [self addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(25);
        make.right.mas_equalTo(-25);
        make.height.mas_equalTo(210+desHeight+10);
        make.centerY.mas_equalTo(weakSelf);
    }];
    
    //标题
    UILabel *titleLabel = [UILabel new];
    titleLabel.text = NSLocalizedString(@"jiaoyan_mima", @"校验密码");
    titleLabel.font = [UIFont systemFontOfSize:22];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [contentView addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.left.right.mas_equalTo(0);
        make.height.mas_equalTo(20);
    }];
    
    //标题
    self.desLabel = [UILabel new];
    self.desLabel.text = NSLocalizedString(@"moren_mima", @"默认密码：HiLink(区分大小写)");
    self.desLabel.font = [UIFont systemFontOfSize:18];
    self.desLabel.textColor = MAIN_COLOE;
    self.desLabel.numberOfLines = 0;
    self.desLabel.textAlignment = NSTextAlignmentCenter;
    [contentView addSubview:self.desLabel];
    [self.desLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(titleLabel.mas_bottom).offset(10);
        make.left.right.mas_equalTo(0);
        make.height.mas_equalTo(desHeight+10);
    }];
    
    
    self.psdTextField = [UITextField new];
    self.psdTextField.layer.borderWidth = 1;
    self.psdTextField.layer.cornerRadius = 5;
    self.psdTextField.layer.borderColor = MAIN_COLOE.CGColor;
    self.psdTextField.clipsToBounds = YES;
    self.psdTextField.textAlignment = NSTextAlignmentCenter;
    self.psdTextField.borderStyle = UITextBorderStyleNone;
//    self.psdTextField.keyboardAppearance = UIKeyboardAppearanceDark;
    self.psdTextField.placeholder = NSLocalizedString(@"shuru_kongzhi_mima", @"请输入6位的控制密码");
    self.psdTextField.delegate = self;
    [contentView addSubview:self.psdTextField];
    [self.psdTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(-10);
        make.height.mas_equalTo(50);
        make.top.mas_equalTo(weakSelf.desLabel.mas_bottom).offset(10);
    }];
    
    //标题
    self.errorLabel = [UILabel new];
    self.errorLabel.text = NSLocalizedString(@"mima_cuowu", @"密码错误");
    self.errorLabel.font = [UIFont systemFontOfSize:14];
    self.errorLabel.textColor = [UIColor redColor];
    [contentView addSubview:self.errorLabel];
    self.errorLabel.hidden = YES;
    [self.errorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.psdTextField.mas_bottom).offset(3);
        make.left.mas_equalTo(10);
        make.height.mas_equalTo(13);
        make.right.mas_equalTo(-10);
    }];
    
    //确认按钮
    UIButton *confirmButton = [UIButton new];
    [confirmButton setTitle:NSLocalizedString(@"que_ding", @"确定") forState:UIControlStateNormal];
    [confirmButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    confirmButton.backgroundColor = MAIN_COLOE;
    confirmButton.layer.cornerRadius = 5.5;
    confirmButton.clipsToBounds = YES;
    [confirmButton addTarget:self action:@selector(enterConfirmButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:confirmButton];
    [confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-20);
        make.width.mas_equalTo((kScreenWidth-25*2-20*3)/2.0);
        make.bottom.mas_equalTo(-20);
        make.height.mas_equalTo(40);
    }];
    
    //取消按钮
    UIButton *cancelButton = [UIButton new];
    [cancelButton setTitle:NSLocalizedString(@"qu_xiao", @"取消") forState:UIControlStateNormal];
    [cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    cancelButton.backgroundColor = [UIColor ims_colorWithHexRGB:0xAEABAB];
    cancelButton.layer.cornerRadius = 5.5;
    cancelButton.clipsToBounds = YES;
    [cancelButton addTarget:self action:@selector(enterCancelButton) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:cancelButton];
    [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(20);
        make.width.mas_equalTo((kScreenWidth-25*2-20*3)/2.0);
        make.bottom.mas_equalTo(-20);
        make.height.mas_equalTo(40);
    }];
}

//点击确定按钮
- (void)enterConfirmButton {
    if([[self.psdTextField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]length]==0) {
        self.errorLabel.hidden = NO;
        return;
    }else if(self.psdTextField.text.length == 6){
        if (self.pwdBlock) {
            [self removeFromSuperview];
            self.pwdBlock(self.psdTextField.text);
        }
        [self removeFromSuperview];
    }else {
        self.errorLabel.hidden = NO;
    }
    
    

}

- (void)setDefaulPassword:(NSString *)defaulPassword {
    _defaulPassword = defaulPassword;
    self.desLabel.text = [NSString stringWithFormat:@"%@%@",NSLocalizedString(@"moren_mima", @"默认密码："),defaulPassword];
}

-(void)setCurrentPassword:(NSString *)currentPassword {
    _currentPassword = currentPassword;
    self.psdTextField.text = currentPassword;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    

    if (textField == self.psdTextField) {
        if (range.length == 1 && string.length == 0) {
            return YES;

        }

        else if (self.psdTextField.text.length >= 6) {
            self.psdTextField.text = [textField.text substringToIndex:6];

            return NO;

        }

    }

    self.errorLabel.hidden = YES;
    return YES;

}

//点击取消按钮
- (void)enterCancelButton {
    if (self.cancelBlock) {
        self.cancelBlock();
    }
}

@end
