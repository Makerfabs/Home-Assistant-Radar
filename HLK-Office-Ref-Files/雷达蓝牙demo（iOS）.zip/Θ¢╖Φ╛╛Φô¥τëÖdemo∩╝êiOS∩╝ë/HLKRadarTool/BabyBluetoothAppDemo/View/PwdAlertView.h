//
//  PwdAlertView.h
//  SmartPhotoFrame
//
//  Created by 佐文周 on 2022/6/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^PWDBlock)(NSString *pwdStr);
typedef void(^CancelBlock)(void);

@interface PwdAlertView : UIView

@property (nonatomic, strong) UILabel *errorLabel;/**< 错误码 */

//单例模式
+ (instancetype)sharePWDAlertView;

@property (nonatomic, strong) NSString *defaulPassword;
@property (nonatomic, strong) NSString *currentPassword;

- (instancetype)initWithFrame:(CGRect)frame andDefaultPassword:(NSString *)pwd;

- (instancetype)initWithFrame:(CGRect)frame andPassword:(NSString *)password;

@property (nonatomic, strong) PWDBlock pwdBlock;
@property (nonatomic, strong) CancelBlock cancelBlock;

@end

NS_ASSUME_NONNULL_END
