//
//  ZZW_AlertView.h
//  HLKRadarTool
//
//  Created by 佐文周 on 2023/2/6.
//  Copyright © 2023 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^AngainBlock)(void);
typedef void(^CancelBlock)(void);

@interface ZZW_AlertView : UIView

@property (nonatomic, copy) AngainBlock angainBlock;
@property (nonatomic, copy) CancelBlock cancelBlock;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title andMessage:(NSString *)message;


- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title message:(NSString *)message confirmButtonTitle:(NSString *)confirmButtonTitle cancelButtonTitle:(NSString *)cancelButtonTitle;
@end

NS_ASSUME_NONNULL_END
