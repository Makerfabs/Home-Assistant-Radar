//
//  ZZW_Tool.h
//  SmartPhotoFrame
//
//  Created by mqw on 2021/9/14.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface ZZW_Tool : NSObject

/// 获取文字宽度
/// @param text 文字内容
/// @param font 文字字体
/// @param height 文字高度
+ (CGFloat)getStringWidthWithText:(NSString *)text font:(UIFont *)font viewHeight:(CGFloat)height;


/// 获取文字高度
/// @param text 文字内容
/// @param font 文字字体
/// @param width 文字宽度度
+ (CGFloat)getStringHeightWithText:(NSString *)text font:(UIFont *)font viewWidth:(CGFloat)width;

+ (NSString *)ZZW_weekdaySortWithDayArray:(NSArray *)array;

/// 判断字符串是否为空
/// @param string <#string description#>
+ (BOOL)isEmptyString:(NSString *)string;


+ (NSString *)timeWithYearMonthDayCountDown:(double)timestamp;

+ (NSString *)getTime;


/// 获取当前语言标识
+ (NSString*)getPreferredLanguage;
@end

NS_ASSUME_NONNULL_END
