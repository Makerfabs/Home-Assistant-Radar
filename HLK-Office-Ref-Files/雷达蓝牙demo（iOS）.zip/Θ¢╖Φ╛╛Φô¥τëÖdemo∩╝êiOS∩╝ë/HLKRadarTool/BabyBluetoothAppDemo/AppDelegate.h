//
//  AppDelegate.h
//  BabyBluetoothAppDemo
//
//  Created by 刘彦玮 on 15/8/1.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kOnRecvPipeData                 @"kOnRecvPipeData"
#define kOnRecvPipeDataALL              @"kOnRecvPipeDataALL"
#define OnFinish                                 @"OnFinish"
#define kOnWritePipeData                @"kOnWritePipeData"
#define kOnDisconnectPeripheral                @"kOnDisconnectPeripheral"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;


@end

