//
//  UIViewController+HUDView.m
//
//  Created by muda on 2017/11/20.
//  Copyright © 2017年 muda. All rights reserved.
//

#import "UIViewController+HUD.h"
#import "MBProgressHUD.h"

@implementation UIViewController (HUD)

- (void)ims_showHUDWithIndicator {
    [self ims_hideHUD];
    
    MBProgressHUD *hud = [MBProgressHUD HUDForView:self.view];
    if (hud) {
        hud.mode = MBProgressHUDModeIndeterminate;
    } else {
        hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    
    [hud show:YES];
}
- (void)ims_showHUDIndicatorWithMessage:(NSString *)message {
    [self ims_hideHUD];
    
    MBProgressHUD *hud = [MBProgressHUD HUDForView:self.view];
    if (hud) {
        hud.mode = MBProgressHUDModeIndeterminate;
    } else {
        hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    hud.labelText = message;
    [hud show:YES];
}

- (void)ims_showHUDWithMessage:(NSString *)message{
    [self ims_hideHUD];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeText;
    hud.detailsLabelFont = [UIFont systemFontOfSize: 16];
    hud.detailsLabelText = message ?: @"";
    [hud hide:YES afterDelay:1.0];
}



- (void)ims_hideHUD {
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}


- (void)showInWindowWithMessage:(NSString *)message{
    [self hidenViewFromWindow];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[kAppDelegate window] animated:YES];
    hud.mode = MBProgressHUDModeText;
    hud.detailsLabelFont = [UIFont systemFontOfSize: 16];
    hud.detailsLabelText = message ?: @"";
    [hud hide:YES afterDelay:1.0];
//    [hud hideAnimated:YES afterDelay:1.0];
}

- (void)hidenViewFromWindow {
    [MBProgressHUD hideHUDForView:[kAppDelegate window] animated:YES];
}

@end
